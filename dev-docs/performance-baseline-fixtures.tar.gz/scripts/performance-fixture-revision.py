#!/usr/bin/env python3
"""Print a stable content revision for the performance harness."""

import hashlib
import pathlib


FILES = (
    "performance-harness/Cargo.toml",
    "performance-harness/Cargo.lock",
    "performance-harness/fixtures.csv",
    "performance-harness/src/alloc.rs",
    "performance-harness/src/fixtures.rs",
    "performance-harness/src/main.rs",
    "performance-harness/src/measure.rs",
)


def main() -> None:
    root = pathlib.Path(__file__).resolve().parent.parent
    digest = hashlib.sha256()
    for relative in FILES:
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update((root / relative).read_bytes())
        digest.update(b"\0")
    print(digest.hexdigest())


if __name__ == "__main__":
    main()

