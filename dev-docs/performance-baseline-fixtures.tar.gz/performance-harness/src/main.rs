mod alloc;
mod fixtures;
mod measure;

use fixtures::*;
use measure::{allocated, timed, Sample};
use sdax::host::engine::{Effect, Event, Machine};
use sdax::host::{bodies_of_with_input, Observer};
use sdax::{Outcome, Plan};
use sdax_tokio::{PlanStart, TokioRuntime};
use std::collections::VecDeque;
use std::future::Future;
use std::hint::black_box;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;

#[global_allocator]
static ALLOCATOR: alloc::CountingAllocator = alloc::CountingAllocator;

#[derive(Clone, Copy)]
struct Config {
    samples: usize,
    warmup: usize,
    build_samples: usize,
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    match args.get(1).map(String::as_str) {
        Some("verify") => verify(),
        Some("bench") => {
            verify();
            let cfg = Config {
                samples: value(&args, "--samples", 40),
                warmup: value(&args, "--warmup", 8),
                build_samples: value(&args, "--build-samples", 20),
            };
            measure::write_csv(&bench(cfg));
        }
        _ => {
            eprintln!(
                "usage: sdax-performance-harness verify | bench [--samples N] [--warmup N] [--build-samples N]"
            );
            std::process::exit(2);
        }
    }
}

fn value(args: &[String], flag: &str, default: usize) -> usize {
    args.windows(2)
        .find(|pair| pair[0] == flag)
        .and_then(|pair| pair[1].parse().ok())
        .unwrap_or(default)
}

fn verify() {
    let executor = runtime();
    let rt = adapter(&executor, None);

    for shape in [Shape::Chain, Shape::Wide, Shape::Sparse] {
        let spec = GraphSpec::generate(shape, 10);
        let plan = graph(&spec, false);
        let (report, checksum) = run_finite(&executor, rt.clone(), &plan, 17);
        assert_eq!(report.outcome, Outcome::Ok, "{shape:?}");
        assert!(report.is_clean(), "{shape:?}: {report}");
        assert_ne!(checksum, 0);
    }
    eprintln!("fixture verification: graphs ok");

    let releases = Arc::new(AtomicU64::new(0));
    let plan = startup_failure(releases.clone());
    let (report, _) = run_finite(&executor, rt.clone(), &plan, 1);
    assert_eq!(report.outcome, Outcome::Failed);
    assert_eq!(releases.load(Ordering::Acquire), 1);
    eprintln!("fixture verification: startup failure ok");

    let downstream = Arc::new(AtomicU64::new(0));
    let upstream = Arc::new(AtomicU64::new(0));
    let plan = cleanup_error_keeps_upstream(downstream.clone(), upstream.clone());
    let (report, _) = run_finite(&executor, rt.clone(), &plan, 1);
    assert_eq!(report.outcome, Outcome::Ok);
    assert_eq!(report.cleanup_failures.len(), 1);
    assert_eq!(downstream.load(Ordering::Acquire), 1);
    assert_eq!(upstream.load(Ordering::Acquire), 1);
    eprintln!("fixture verification: cleanup failure ok");

    let acquired = Arc::new(AtomicU64::new(0));
    let released = Arc::new(AtomicU64::new(0));
    let plan = cancel_after_acquire(acquired.clone(), released.clone());
    let report = executor.block_on(async {
        let running = plan.start(rt.clone(), 1);
        let handle = running.handle();
        await_cancel_after(running, handle, acquired.clone(), 1).await
    });
    assert_eq!(report.outcome, Outcome::Cancelled);
    assert_eq!(released.load(Ordering::Acquire), 1);
    eprintln!("fixture verification: cancellation ok");

    let compensated = Arc::new(AtomicU64::new(0));
    let plan = known_receipt(compensated.clone());
    let (report, _) = run_finite(&executor, rt.clone(), &plan, 5);
    assert_eq!(report.outcome, Outcome::Ok);
    assert_eq!(compensated.load(Ordering::Acquire), 1);
    let plan = retry_once();
    let (report, _) = run_finite(&executor, rt.clone(), &plan, 5);
    assert_eq!(report.outcome, Outcome::Ok);
    assert_eq!(report.output.as_deref(), Some(&5));

    let plan = dynamic_instances(3);
    let report = executor.block_on(async {
        let mut running = plan.start(rt.clone(), 4);
        running.ready().await.expect("dynamic ready");
        running.shutdown();
        running.await
    });
    assert_eq!(report.outcome, Outcome::Ok);
    assert!(report.is_clean(), "{report}");
    assert_eq!(rt.tracked(), 0, "correctness fixtures leave no tasks");
    eprintln!("fixture verification: ok");
}

fn bench(cfg: Config) -> Vec<Sample> {
    let mut out = Vec::new();
    benchmark_runtime_setup(cfg, &mut out);
    for nodes in [1, 10, 100, 1_000] {
        for shape in [Shape::Chain, Shape::Wide, Shape::Sparse] {
            benchmark_graph(cfg, shape, nodes, false, &mut out);
        }
    }
    benchmark_graph(cfg, Shape::Chain, 1, true, &mut out);
    benchmark_resources(cfg, &mut out);
    benchmark_safety_paths(cfg, &mut out);
    benchmark_components(cfg, &mut out);
    benchmark_resident(cfg, &mut out);
    benchmark_dynamic(cfg, &mut out);
    benchmark_trace(cfg, &mut out);
    benchmark_application(cfg, &mut out);
    out
}

fn benchmark_runtime_setup(cfg: Config, out: &mut Vec<Sample>) {
    for sample in 0..cfg.samples {
        let (nanos, checksum) = timed(|| {
            let executor = runtime();
            let rt = adapter(&executor, None);
            let checksum = rt.tracked() as u64;
            drop(rt);
            drop(executor);
            ((), checksum)
        });
        push(
            out,
            "adapter_setup",
            "current_thread_runtime",
            0,
            0,
            sample,
            nanos,
            0,
            0,
            checksum,
        );
    }
}

fn benchmark_graph(cfg: Config, shape: Shape, nodes: usize, yielding: bool, out: &mut Vec<Sample>) {
    let label = if yielding {
        format!("tiny_yield_{shape:?}").to_lowercase()
    } else {
        GraphSpec::generate(shape, nodes).label().to_string()
    };
    for sample in 0..cfg.build_samples {
        let (nanos, checksum) = timed(|| {
            let spec = GraphSpec::generate(shape, nodes);
            let checksum = spec.names.iter().map(String::len).sum::<usize>() as u64;
            (spec, checksum)
        });
        push(
            out,
            "fixture_generation",
            &label,
            nodes,
            nodes - 1,
            sample,
            nanos,
            0,
            0,
            checksum,
        );
    }
    let spec = GraphSpec::generate(shape, nodes);
    benchmark_build(
        cfg,
        &label,
        nodes,
        spec.edges(),
        || graph(&spec, yielding),
        out,
    );
    let plan = graph(&spec, yielding);
    benchmark_finite_execution(cfg, &label, nodes, spec.edges(), &plan, None, out);
    benchmark_state_setup(cfg, &label, nodes, spec.edges(), &plan, out);
    if !yielding && shape == Shape::Chain {
        benchmark_machine(cfg, &label, nodes, spec.edges(), &plan, out);
    }
}

fn benchmark_build(
    cfg: Config,
    label: &str,
    nodes: usize,
    edges: usize,
    build: impl Fn() -> Plan<u64, u64>,
    out: &mut Vec<Sample>,
) {
    for sample in 0..cfg.build_samples {
        let (nanos, checksum) = timed(|| {
            let plan = build();
            let checksum = plan.name().len() as u64;
            (plan, checksum)
        });
        push(
            out,
            "plan_build",
            label,
            nodes,
            edges,
            sample,
            nanos,
            0,
            0,
            checksum,
        );
    }
    let (allocations, bytes, checksum) = allocated(|| {
        let plan = build();
        let checksum = plan.name().len() as u64;
        (plan, checksum)
    });
    push(
        out,
        "plan_build_alloc",
        label,
        nodes,
        edges,
        0,
        0,
        allocations,
        bytes,
        checksum,
    );
}

fn benchmark_finite_execution(
    cfg: Config,
    label: &str,
    nodes: usize,
    edges: usize,
    plan: &Plan<u64, u64>,
    observer: Option<Arc<dyn Observer>>,
    out: &mut Vec<Sample>,
) {
    benchmark_finite_execution_phase(
        cfg,
        "engine_execution",
        label,
        nodes,
        edges,
        plan,
        observer,
        out,
    );
}

#[allow(clippy::too_many_arguments)]
fn benchmark_finite_execution_phase(
    cfg: Config,
    phase: &'static str,
    label: &str,
    nodes: usize,
    edges: usize,
    plan: &Plan<u64, u64>,
    observer: Option<Arc<dyn Observer>>,
    out: &mut Vec<Sample>,
) {
    let executor = runtime();
    let rt = adapter(&executor, observer);
    for _ in 0..cfg.warmup {
        consume_run(&executor, rt.clone(), plan, 7);
    }
    for sample in 0..cfg.samples {
        let (nanos, checksum) = timed(|| consume_run(&executor, rt.clone(), plan, sample as u64));
        push(
            out, phase, label, nodes, edges, sample, nanos, 0, 0, checksum,
        );
    }
    let (allocations, bytes, checksum) =
        allocated(|| consume_run(&executor, rt.clone(), plan, 0x5a5a));
    let allocation_phase = if phase == "representative_application" {
        "representative_application_alloc"
    } else {
        "engine_execution_alloc"
    };
    push(
        out,
        allocation_phase,
        label,
        nodes,
        edges,
        0,
        0,
        allocations,
        bytes,
        checksum,
    );
    assert_eq!(rt.tracked(), 0);
}

fn consume_run(
    executor: &tokio::runtime::Runtime,
    rt: Arc<TokioRuntime>,
    plan: &Plan<u64, u64>,
    input: u64,
) -> ((), u64) {
    let (report, checksum) = run_finite(executor, rt, plan, black_box(input));
    assert!(matches!(
        report.outcome,
        Outcome::Ok | Outcome::Failed | Outcome::Cancelled
    ));
    drop(report);
    ((), checksum)
}

fn benchmark_state_setup(
    cfg: Config,
    label: &str,
    nodes: usize,
    edges: usize,
    plan: &Plan<u64, u64>,
    out: &mut Vec<Sample>,
) {
    for sample in 0..cfg.samples {
        let (nanos, checksum) = timed(|| {
            let machine = Machine::with_input(plan).expect("machine");
            let checksum = machine.nodes().len() as u64;
            drop(machine);
            ((), checksum)
        });
        push(
            out,
            "machine_state_setup",
            label,
            nodes,
            edges,
            sample,
            nanos,
            0,
            0,
            checksum,
        );
        let (nanos, checksum) = timed(|| {
            let bodies = bodies_of_with_input(plan, sample as u64);
            let checksum = bodies.export().is_some() as u64;
            drop(bodies);
            ((), checksum)
        });
        push(
            out,
            "body_state_setup",
            label,
            nodes,
            edges,
            sample,
            nanos,
            0,
            0,
            checksum,
        );
    }
}

fn benchmark_machine(
    cfg: Config,
    label: &str,
    nodes: usize,
    edges: usize,
    plan: &Plan<u64, u64>,
    out: &mut Vec<Sample>,
) {
    for sample in 0..cfg.samples {
        let mut machine = Machine::with_input(plan).expect("machine");
        let (nanos, checksum) = timed(|| {
            let checksum = drive_machine(&mut machine);
            ((), checksum)
        });
        push(
            out,
            "pure_machine_events_preseeded",
            label,
            nodes,
            edges,
            sample,
            nanos,
            0,
            0,
            checksum,
        );
    }
}

fn drive_machine(machine: &mut Machine) -> u64 {
    let mut effects: VecDeque<Effect> = machine.begin().into();
    let mut checksum = 0u64;
    while let Some(effect) = effects.pop_front() {
        match effect {
            Effect::Spawn { node, attempt } | Effect::SpawnBlocking { node, attempt } => {
                checksum ^= node.idx as u64 ^ attempt as u64;
                effects.extend(machine.step(Event::Started(node)));
                effects.extend(machine.step(Event::NodeOk(node)));
            }
            Effect::PublishReady { node } => {
                effects.extend(machine.step(Event::ReadyPublished {
                    node,
                    result: Ok(()),
                }));
            }
            Effect::End(outcome) => {
                checksum ^= match outcome {
                    Outcome::Ok => 1,
                    Outcome::Failed => 2,
                    Outcome::Cancelled => 3,
                }
            }
            Effect::Emit(event) => checksum ^= event.at.as_nanos(),
            Effect::CancelTimer(_) | Effect::Timer { .. } => {}
            other => panic!("unsupported pure-machine fixture effect: {other:?}"),
        }
    }
    let report = machine.take_report().expect("machine report");
    checksum ^ report.faults.len() as u64
}

fn benchmark_resources(cfg: Config, out: &mut Vec<Sample>) {
    for (label, kind) in [
        ("resource_normal", 0u8),
        ("resource_release_failure", 1),
        ("resource_startup_failure", 2),
        ("resource_cleanup_error_upstream", 3),
    ] {
        let a = Arc::new(AtomicU64::new(0));
        let b = Arc::new(AtomicU64::new(0));
        let plan = match kind {
            0 => tiny_resource(a.clone(), false),
            1 => tiny_resource(a.clone(), true),
            2 => startup_failure(a.clone()),
            _ => cleanup_error_keeps_upstream(a.clone(), b.clone()),
        };
        benchmark_finite_execution(
            cfg,
            label,
            if kind == 3 { 3 } else { 2 },
            1,
            &plan,
            None,
            out,
        );
    }
    benchmark_cancel(cfg, out);
}

fn benchmark_safety_paths(cfg: Config, out: &mut Vec<Sample>) {
    let compensated = Arc::new(AtomicU64::new(0));
    let plan = known_receipt(compensated);
    benchmark_finite_execution(cfg, "effect_known_receipt", 1, 0, &plan, None, out);
    let plan = retry_once();
    benchmark_finite_execution(cfg, "retry_one_failure", 1, 0, &plan, None, out);
}

fn benchmark_cancel(cfg: Config, out: &mut Vec<Sample>) {
    let executor = runtime();
    let rt = adapter(&executor, None);
    let acquired = Arc::new(AtomicU64::new(0));
    let released = Arc::new(AtomicU64::new(0));
    let plan = cancel_after_acquire(acquired.clone(), released.clone());
    for sample in 0..cfg.samples {
        let before = released.load(Ordering::Acquire);
        let (nanos, checksum) = timed(|| {
            let report = executor.block_on(async {
                let running = plan.start(rt.clone(), sample as u64);
                let handle = running.handle();
                let target = acquired.load(Ordering::Acquire) + 1;
                await_cancel_after(running, handle, acquired.clone(), target).await
            });
            let checksum = report.cleanup_failures.len() as u64 + 3;
            drop(report);
            ((), checksum)
        });
        assert_eq!(released.load(Ordering::Acquire), before + 1);
        push(
            out,
            "engine_execution",
            "resource_cancel_after_acquire",
            1,
            0,
            sample,
            nanos,
            0,
            0,
            checksum,
        );
    }
}

async fn await_cancel_after(
    running: sdax_tokio::Running<u64>,
    handle: sdax_tokio::RunHandle,
    acquired: Arc<AtomicU64>,
    target: u64,
) -> sdax::Report<u64> {
    let mut running = Box::pin(running);
    let mut cancelled = false;
    std::future::poll_fn(move |cx| {
        if let std::task::Poll::Ready(report) = running.as_mut().poll(cx) {
            return std::task::Poll::Ready(report);
        }
        if !cancelled && acquired.load(Ordering::Acquire) >= target {
            handle.cancel();
            cancelled = true;
        }
        cx.waker().wake_by_ref();
        std::task::Poll::Pending
    })
    .await
}

fn benchmark_components(cfg: Config, out: &mut Vec<Sample>) {
    for nodes in [10, 100] {
        let flat = flat_component_equivalent(nodes);
        benchmark_finite_execution(cfg, "component_flat", nodes, nodes - 1, &flat, None, out);
        let nested = nested_component(nodes);
        benchmark_finite_execution(
            cfg,
            "component_nested",
            nodes + 3,
            nodes + 2,
            &nested,
            None,
            out,
        );
    }
}

fn benchmark_resident(cfg: Config, out: &mut Vec<Sample>) {
    let plan = resident_noop();
    let executor = runtime();
    let rt = adapter(&executor, None);
    for _ in 0..cfg.warmup {
        consume_resident(&executor, rt.clone(), &plan, 1);
    }
    for sample in 0..cfg.samples {
        let (nanos, checksum) =
            timed(|| consume_resident(&executor, rt.clone(), &plan, sample as u64));
        push(
            out,
            "engine_execution",
            "resident_ready_shutdown",
            1,
            0,
            sample,
            nanos,
            0,
            0,
            checksum,
        );
    }
}

fn consume_resident(
    executor: &tokio::runtime::Runtime,
    rt: Arc<TokioRuntime>,
    plan: &Plan<(), u64>,
    input: u64,
) -> ((), u64) {
    let report = executor.block_on(async {
        let mut running = plan.start(rt, input);
        running.ready().await.expect("resident ready");
        running.shutdown();
        running.await
    });
    assert_eq!(report.outcome, Outcome::Ok);
    let checksum = report.cleanup_failures.len() as u64 + 1;
    drop(report);
    ((), checksum)
}

fn benchmark_dynamic(cfg: Config, out: &mut Vec<Sample>) {
    for instances in [1, 10, 100] {
        let label = format!("dynamic_live_instances_{instances}");
        let plan = dynamic_instances(3);
        let executor = runtime();
        let rt = adapter(&executor, None);
        for _ in 0..cfg.warmup {
            consume_dynamic(&executor, rt.clone(), &plan, instances);
        }
        for sample in 0..cfg.samples {
            let (nanos, checksum) =
                timed(|| consume_dynamic(&executor, rt.clone(), &plan, instances));
            push(
                out,
                "engine_execution",
                &label,
                3,
                2,
                sample,
                nanos,
                0,
                0,
                checksum ^ instances as u64,
            );
        }
        let (allocations, bytes, checksum) =
            allocated(|| consume_dynamic(&executor, rt.clone(), &plan, instances));
        push(
            out,
            "engine_execution_alloc",
            &label,
            3,
            2,
            instances,
            0,
            allocations,
            bytes,
            checksum ^ instances as u64,
        );
    }
}

fn consume_dynamic(
    executor: &tokio::runtime::Runtime,
    rt: Arc<TokioRuntime>,
    plan: &Plan<(), usize>,
    instances: usize,
) -> ((), u64) {
    let report = executor.block_on(async {
        let mut running = plan.start(rt, instances);
        running.ready().await.expect("dynamic ready");
        running.shutdown();
        running.await
    });
    assert_eq!(report.outcome, Outcome::Ok);
    let checksum = report.cleanup_failures.len() as u64 + 1;
    drop(report);
    ((), checksum)
}

fn benchmark_trace(cfg: Config, out: &mut Vec<Sample>) {
    let plan = graph(&GraphSpec::generate(Shape::Chain, 100), false);
    benchmark_finite_execution(cfg, "trace_default", 100, 99, &plan, None, out);
    let observer = Arc::new(CountingObserver(AtomicU64::new(0)));
    benchmark_finite_execution(
        cfg,
        "trace_observer",
        100,
        99,
        &plan,
        Some(observer.clone()),
        out,
    );
    assert!(observer.0.load(Ordering::Relaxed) > 0);
}

fn benchmark_application(cfg: Config, out: &mut Vec<Sample>) {
    for nodes in [10, 100] {
        let plan = cpu_application(nodes);
        benchmark_finite_execution_phase(
            cfg,
            "representative_application",
            "application_hash_sdax",
            nodes,
            nodes - 1,
            &plan,
            None,
            out,
        );
        for sample in 0..cfg.samples {
            let (nanos, checksum) = timed(|| ((), handwritten_hash(nodes, sample as u64)));
            push(
                out,
                "representative_application",
                "application_hash_handwritten",
                nodes,
                nodes - 1,
                sample,
                nanos,
                0,
                0,
                checksum,
            );
        }
    }
}

fn handwritten_hash(nodes: usize, input: u64) -> u64 {
    let mut value = input;
    for i in 1..nodes {
        value ^= i as u64;
        for _ in 0..64 {
            value = value.wrapping_mul(0x9e37_79b9_7f4a_7c15).rotate_left(13) ^ 0xa5a5_a5a5;
        }
    }
    black_box(value)
}

#[allow(clippy::too_many_arguments)]
fn push(
    out: &mut Vec<Sample>,
    phase: &'static str,
    workload: &str,
    nodes: usize,
    edges: usize,
    sample: usize,
    nanos: u128,
    allocations: u64,
    allocated_bytes: u64,
    checksum: u64,
) {
    out.push(Sample {
        phase,
        workload: workload.to_string(),
        nodes,
        edges,
        sample,
        nanos,
        allocations,
        allocated_bytes,
        checksum,
    });
}
