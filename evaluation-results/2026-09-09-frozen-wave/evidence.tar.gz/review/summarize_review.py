"""Read-only evaluation inputs; writes small summaries only in review directory."""
from pathlib import Path
import collections
import datetime
import hashlib
import json

OUT = Path(__file__).resolve().parent
RUN = Path('/Users/owebeeone/limbo/sdax-wz/sdax-rs/evaluation-harness/runs/run-8845efbb64c24573a19c9f3290725f21')
MODELS = ['gemma4:26b', 'qwen3.8:27b']
CASES = ['e1', 'e2', 'f1', 'f2', 'f3', 'f4', 'f5', 'f6', 'r1', 'r2']
METRICS = ['prompt_eval_count', 'eval_count', 'duration_seconds', 'load_duration', 'prompt_eval_duration', 'eval_duration', 'total_duration']
FREEZE = Path('/Users/owebeeone/limbo/sdax-wz/artifacts/remediation-20260909/integrated-freeze-0320/frozen.json')


def read(path):
    return json.loads(path.read_text()) if path.exists() else None


def main():
    events = [json.loads(line) for line in (RUN.parent / 'calls.jsonl').read_text().splitlines()]
    reservations = {(e['model'], e['trial'], e['attempt']): e for e in events if e['event'] == 'reserve'}
    terminal = {e['call_id']: e for e in events if e['event'] == 'terminal'}
    trials = []
    for model in MODELS:
        for case in CASES:
            slots = []
            for attempt in range(3):
                d = RUN / model.replace(':', '_') / case / str(attempt)
                charge = reservations.get((model, case, attempt))
                result = read(d / 'result.json')
                if not charge and not result:
                    continue
                inference = read(d / 'inference.json')
                review = read(OUT / f'{model.replace(":", "_")}-{case}-{attempt}.json')
                source = d / 'src/candidate.rs'
                if not source.exists():
                    source = d / 'answer.txt'
                actual_hash = hashlib.sha256(source.read_bytes()).hexdigest() if source.exists() else None
                slots.append(dict(attempt=attempt, charged=bool(charge), call_id=charge['call_id'] if charge else None,
                                  terminal=terminal.get(charge['call_id']) if charge else None,
                                  executable=result or {'status': 'charged_without_result' if charge else 'missing'},
                                  cost=inference, structural=review['structural_result'] if review else 'pending',
                                  reviewed_source_hash_matches=(review.get('source_sha256') == actual_hash) if review else False,
                                  source_sha256=actual_hash))
            track = 'reconstructed_exposed' if case.startswith('e') else 'reduction_repeat' if case.startswith('r') else 'fresh'
            known = [s['cost'] for s in slots if s['cost']]
            trials.append(dict(model=model, case=case, track=track, attempts=slots, final_attempt=slots[-1] if slots else None,
                               charged_calls=sum(s['charged'] for s in slots), measured_calls=len(known),
                               known_cost={m: sum(c.get(m, 0) for c in known) for m in METRICS},
                               missing_cost_calls=sum(s['charged'] and not s['cost'] for s in slots)))
    totals = {}
    for model in MODELS:
        selected = [t for t in trials if t['model'] == model]
        slots = [s for t in selected for s in t['attempts']]
        totals[model] = dict(charged_calls=sum(t['charged_calls'] for t in selected),
                             measured_calls=sum(t['measured_calls'] for t in selected),
                             missing_cost_calls=sum(t['missing_cost_calls'] for t in selected),
                             known_cost={m: sum(t['known_cost'][m] for t in selected) for m in METRICS},
                             compile=collections.Counter(s['executable'].get('compile', 'unknown') for s in slots),
                             structural=collections.Counter(s['structural'] for s in slots))
        totals[model]['tracks'] = {}
        for track in ['reconstructed_exposed', 'fresh', 'reduction_repeat']:
            ts = [t for t in selected if t['track'] == track]
            totals[model]['tracks'][track] = dict(planned_trials=len(ts),
                started_trials=sum(bool(t['attempts']) for t in ts),
                first_pass_executable=sum(bool(t['attempts']) and t['attempts'][0]['executable'].get('passed', False) for t in ts),
                final_executable=sum(bool(t['final_attempt']) and t['final_attempt']['executable'].get('passed', False) for t in ts),
                final_structural=sum(bool(t['final_attempt']) and t['final_attempt']['structural'] == 'passed' for t in ts))
    freeze = read(FREEZE)
    mismatches = [p for p, expected in freeze['snapshot']['files'].items()
                  if not Path(p).exists() or hashlib.sha256(Path(p).read_bytes()).hexdigest() != expected]
    identifiers = dict(frozen_sha256=hashlib.sha256(FREEZE.read_bytes()).hexdigest(),
                       protocol_sha256=freeze['protocol_sha256'], model_digests=freeze['model_digests'],
                       member_revision='5fbe0ea2608a4ccb5f9eea71852488614ca884ad',
                       managed_root_revision='d1b54c92f3fd8c8b7f8cb45605143596d9407199',
                       frozen_files=len(freeze['snapshot']['files']), current_hash_mismatches=mismatches)
    summary = dict(generated_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), run=str(RUN), identifiers=identifiers,
                   notes=['Per-slot results are authoritative; model-specific root summary files cannot omit a prior model.',
                          'Known costs exclude explicitly unavailable consumed calls; unavailable costs are not zero.',
                          'Structural review is independent agent review, not human reviewability evidence.',
                          'No builds, inference, ledger changes, or frozen-input changes performed by this report.'],
                   totals=totals, trials=trials)
    (OUT / 'aggregate.json').write_text(json.dumps(summary, indent=2) + '\n')
    lines = ['# Independent evaluation review', '',
             'Neither model produced a fully passing program under the combined executable and structural criteria. Both scored 0/10 initial executable passes. Qwen passed all executable checks on f2 after one repair, while its resource acquisition still violated the separately reviewed lazy-registration requirement. Gemma had no executable pass. All 58 available responses failed structural review; one additional consumed Gemma call remains unassessed because its response was lost.', '',
             f'Run: `{RUN.name}`. Final snapshot: {summary["generated_at_utc"]}.', '',
             '| Model | Track | Trials started/planned | Initial executable passes | Final executable passes | Final structural passes |',
             '|---|---|---|---|---|---|']
    for model, total in totals.items():
        for track, counts in total['tracks'].items():
            lines.append(f'| {model} | {track} | {counts["started_trials"]}/{counts["planned_trials"]} | {counts["first_pass_executable"]} | {counts["final_executable"]} | {counts["final_structural"]} |')
    lines += ['', '| Model | Charged / measured calls | Compile passed / failed / not attempted / unknown | Structural failed / uncertain | Known prompt / output tokens | Known request seconds |',
              '|---|---|---|---|---|---|']
    for model, total in totals.items():
        c = total['known_cost']
        comp = ' / '.join(str(total['compile'].get(k, 0)) for k in ['passed', 'failed', 'not_attempted', 'unknown'])
        struct = f'{total["structural"].get("failed", 0)} / {total["structural"].get("not_assessed_uncertain", 0)}'
        lines.append(f'| {model} | {total["charged_calls"]} / {total["measured_calls"]} | {comp} | {struct} | {c["prompt_eval_count"]} / {c["eval_count"]} | {c["duration_seconds"]:.3f} |')
    lines += ['',
             'Each attempt below is a separate saved response or charged uncertain slot. Attempt 0 is initial; 1 and 2 are diagnostics-only repairs. Final trial outcome uses the final attempted slot, even when earlier source is available.', '',
             'Exposed cases are reconstructions of documented failures, not exact reproductions. Fresh cases contain six new held-out tasks. Reduction repeats reuse two fresh tasks with the frozen reduced context and are not additional new tasks.', '',
             '| Model | Trial | Track | Attempts | Final compile / behavior / diagnostic | Final structural | Prompt / output tokens (known) | Request seconds (known) | Cost unavailable |',
             '|---|---|---|---|---|---|---|---|---|']
    for t in trials:
        f = t['final_attempt']
        e = f['executable'] if f else {}
        final = ' / '.join(e.get(k, 'pending') for k in ['compile', 'behavior', 'diagnostic'])
        c = t['known_cost']
        attempts = ', '.join(str(s['attempt']) for s in t['attempts']) or 'none'
        lines.append(f'| {t["model"]} | {t["case"]} | {t["track"]} | {attempts} | {final} | {f["structural"] if f else "pending"} | {c["prompt_eval_count"]} / {c["eval_count"]} | {c["duration_seconds"]:.3f} | {t["missing_cost_calls"]} |')
    lines += ['', '## Frozen identity and protocol', '',
              f'Member source: `{identifiers["member_revision"]}`. Managed root: `{identifiers["managed_root_revision"]}`. The protocol baseline field records the earlier design baseline ce339a5; actual tested source is the integrated member and frozen per-file manifest.', '',
              f'Frozen manifest SHA-256: `{identifiers["frozen_sha256"]}`. Protocol SHA-256: `{identifiers["protocol_sha256"]}`. Current read-only verification: {identifiers["frozen_files"]} frozen files, {len(mismatches)} hash mismatches.', '',
              *[f'- {model}: `{digest}`' for model, digest in freeze['model_digests'].items()], '',
              'Ollama 0.33.0-dabeest through the pre-existing local tunnel. Equal caps: 30 calls/model, 60 total, at most initial plus two repairs per trial, 4096 output tokens, 32768 context tokens, think=false, temperature=0, seed=42. Compact/reduced context caps are 16000/8000 UTF-8 bytes; serialized request cap is 64000 bytes. Only diagnostics are added during repair. Cargo builds are locked and offline.', '',
              '## Evidence and interpretation', '',
              'The per-attempt JSON files contain specific structural findings, source hashes, and the executable snapshot observed during review. The aggregate JSON refreshes executable outcomes from actual per-slot result files and verifies every reviewed source hash. Embedded early review snapshots may precede a completed build. The companion attempts.md lists all 59 charged slots with separate execution dimensions and measured costs; aggregate.json also retains full inference metrics and terminal accounting.', '',
              'Compiler failure leaves behavior and diagnostic tests incomplete; it does not demonstrate that those assertions ran and failed. Malformed/truncated responses are distinguished from compiler failures. Structural defects can be assessed directly in available source even when execution is blocked.', '',
              'One Gemma reduced-context r1 repair (attempt 2) was consumed when disk space ran out. No response, generated code, tokens, or latency survived. It remains uncertain and structurally unassessed. Its missing cost is not treated as zero. The resumed run retained its charge and did not refund it.', '',
              'The fixture support type named Resource can collide with the sdax prelude Resource under two wildcard imports. This is an authoring/fixture confound in affected attempts; independent acquisition, binding, lifecycle, and boundary defects remain separately documented. No inference conclusions about runtime library correctness or human reviewability follow from these failed generated programs.', '',
              'All review operations read saved evidence only. No review builds, inference calls, task hints, ledger edits, or frozen-input changes were performed. Monetary cost was not measured.', '']
    lines += ['## Next authoring hypotheses', '',
              'These are hypotheses for a subsequent separately authorized revision, not established causal findings or permission to extend this protocol.', '',
              '- Make the difference between opening inside lazy cx.hold and registering an already-open value through hold_value concrete in the smallest resource example. This matters even for Qwen f2, whose executable assertions pass.',
              '- Put typed input selection, export-before-build, explicit fixture type aliases, and separate acquire/release captures together in one minimal compilable pattern. Several repairs spend their allowance correcting these local Rust/API details while leaving semantic omissions untouched.',
              '- Contrast a known error with a pending body that times out, then show the exact identified effect and recovery argument shapes and independent completed output. The recovery attempts repeatedly substitute known errors for ambiguity.',
              '- Present service initialization retry, serving restart, stable published handle, resident mode, and cooperative stop in one complete declaration. Generated service code often expresses some pieces while missing the mode or conflating initialization with resource retry.',
              '- Keep nested component binding and full Report boundary examples mechanically checkable; reduced-context outputs show invented APIs and report reconstruction, and combined-failure attempts flatten required nested mounts. The two reduction repeats alone cannot establish a general causal effect of context size.', '']
    (OUT / 'report.md').write_text('\n'.join(lines))
    attempts = ['# Complete attempt accounting', '',
                'Attempt 0 is the initial response; attempts 1/2 are diagnostics-only repairs. Costs cover the measured request only, not builds or review. Unavailable costs remain explicitly unavailable. Full source hashes and timings are in aggregate.json.', '',
                '| Model | Case | Track | Attempt | Compile | Behavior | Diagnostic | Structural | Prompt / output tokens | Request seconds |',
                '|---|---|---|---|---|---|---|---|---|---|']
    for t in trials:
        for s in t['attempts']:
            e = s['executable']
            c = s['cost']
            tokens = f'{c["prompt_eval_count"]} / {c["eval_count"]}' if c else 'unavailable'
            seconds = f'{c["duration_seconds"]:.3f}' if c else 'unavailable'
            attempts.append(f'| {t["model"]} | {t["case"]} | {t["track"]} | {s["attempt"]} | {e.get("compile", "unknown")} | {e.get("behavior", "unknown")} | {e.get("diagnostic", "unknown")} | {s["structural"]} | {tokens} | {seconds} |')
    (OUT / 'attempts.md').write_text('\n'.join(attempts) + '\n')
    print(json.dumps(totals, indent=2))


if __name__ == '__main__':
    main()
