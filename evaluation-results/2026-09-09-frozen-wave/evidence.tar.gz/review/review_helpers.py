from pathlib import Path
import json,hashlib,datetime
RUN=Path('/Users/owebeeone/limbo/sdax-wz/sdax-rs/evaluation-harness/runs/run-8845efbb64c24573a19c9f3290725f21')
OUT=Path(__file__).resolve().parent

def record(model,case,attempt,findings,status='failed'):
    folder=model.replace(':','_');d=RUN/folder/case/str(attempt)
    source=d/'src/candidate.rs'
    if not source.exists():source=d/'answer.txt'
    result=json.loads((d/'result.json').read_text()) if (d/'result.json').exists() else {'status':'pending'}
    row={'model':model,'case':case,'attempt':attempt,'track':result.get('track'),
         'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
         'reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'structural_result':status,'executable_result':result,'findings':findings}
    (OUT/f'{folder}-{case}-{attempt}.json').write_text(json.dumps(row,indent=2)+'\n')
    return row

def note(dimension,status,detail):return dict(dimension=dimension,status=status,detail=detail)
