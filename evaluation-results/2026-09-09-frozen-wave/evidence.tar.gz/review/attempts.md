# Complete attempt accounting

Attempt 0 is the initial response; attempts 1/2 are diagnostics-only repairs. Costs cover the measured request only, not builds or review. Unavailable costs remain explicitly unavailable. Full source hashes and timings are in aggregate.json.

| Model | Case | Track | Attempt | Compile | Behavior | Diagnostic | Structural | Prompt / output tokens | Request seconds |
|---|---|---|---|---|---|---|---|---|---|
| gemma4:26b | e1 | reconstructed_exposed | 0 | failed | incomplete | incomplete | failed | 5889 / 600 | 30.868 |
| gemma4:26b | e1 | reconstructed_exposed | 1 | failed | incomplete | incomplete | failed | 8645 / 628 | 3.719 |
| gemma4:26b | e1 | reconstructed_exposed | 2 | failed | incomplete | incomplete | failed | 7405 / 1055 | 5.943 |
| gemma4:26b | e2 | reconstructed_exposed | 0 | failed | incomplete | incomplete | failed | 5949 / 1151 | 7.396 |
| gemma4:26b | e2 | reconstructed_exposed | 1 | failed | incomplete | incomplete | failed | 11791 / 1209 | 7.232 |
| gemma4:26b | e2 | reconstructed_exposed | 2 | failed | incomplete | incomplete | failed | 12747 / 1261 | 7.900 |
| gemma4:26b | f1 | fresh | 0 | not_attempted | not_measured | not_measured | failed | 5973 / 4096 | 22.734 |
| gemma4:26b | f1 | fresh | 1 | failed | incomplete | incomplete | failed | 10108 / 1245 | 7.117 |
| gemma4:26b | f1 | fresh | 2 | failed | incomplete | incomplete | failed | 9915 / 1317 | 7.236 |
| gemma4:26b | f2 | fresh | 0 | failed | incomplete | incomplete | failed | 5977 / 1345 | 8.429 |
| gemma4:26b | f2 | fresh | 1 | failed | incomplete | incomplete | failed | 12589 / 1322 | 8.042 |
| gemma4:26b | f2 | fresh | 2 | failed | incomplete | incomplete | failed | 11028 / 1388 | 8.033 |
| gemma4:26b | f3 | fresh | 0 | failed | incomplete | incomplete | failed | 6078 / 1161 | 7.857 |
| gemma4:26b | f3 | fresh | 1 | failed | incomplete | incomplete | failed | 9155 / 994 | 7.512 |
| gemma4:26b | f3 | fresh | 2 | not_attempted | not_measured | not_measured | failed | 8862 / 4096 | 22.882 |
| gemma4:26b | f4 | fresh | 0 | failed | incomplete | incomplete | failed | 5990 / 3607 | 21.725 |
| gemma4:26b | f4 | fresh | 1 | failed | incomplete | incomplete | failed | 12877 / 869 | 5.966 |
| gemma4:26b | f4 | fresh | 2 | failed | incomplete | incomplete | failed | 8067 / 868 | 4.887 |
| gemma4:26b | f5 | fresh | 0 | failed | incomplete | incomplete | failed | 6058 / 971 | 6.524 |
| gemma4:26b | f5 | fresh | 1 | failed | incomplete | incomplete | failed | 10104 / 972 | 5.735 |
| gemma4:26b | f5 | fresh | 2 | failed | incomplete | incomplete | failed | 9095 / 952 | 5.395 |
| gemma4:26b | f6 | fresh | 0 | not_attempted | not_measured | not_measured | failed | 6026 / 4096 | 21.500 |
| gemma4:26b | f6 | fresh | 1 | failed | incomplete | incomplete | failed | 10161 / 1460 | 8.046 |
| gemma4:26b | f6 | fresh | 2 | failed | incomplete | incomplete | failed | 14013 / 1742 | 10.795 |
| gemma4:26b | r1 | reduction_repeat | 0 | failed | incomplete | incomplete | failed | 2526 / 1009 | 6.143 |
| gemma4:26b | r1 | reduction_repeat | 1 | failed | incomplete | incomplete | failed | 6946 / 986 | 5.656 |
| gemma4:26b | r1 | reduction_repeat | 2 | unknown | incomplete | incomplete | not_assessed_uncertain | unavailable | unavailable |
| gemma4:26b | r2 | reduction_repeat | 0 | not_attempted | not_measured | not_measured | failed | 2611 / 4096 | 23.316 |
| gemma4:26b | r2 | reduction_repeat | 1 | failed | incomplete | incomplete | failed | 6745 / 2274 | 13.101 |
| gemma4:26b | r2 | reduction_repeat | 2 | failed | incomplete | incomplete | failed | 7609 / 1525 | 9.195 |
| qwen3.8:27b | e1 | reconstructed_exposed | 0 | failed | incomplete | incomplete | failed | 5518 / 597 | 34.112 |
| qwen3.8:27b | e1 | reconstructed_exposed | 1 | failed | incomplete | incomplete | failed | 8141 / 570 | 8.828 |
| qwen3.8:27b | e1 | reconstructed_exposed | 2 | failed | incomplete | incomplete | failed | 8637 / 596 | 9.390 |
| qwen3.8:27b | e2 | reconstructed_exposed | 0 | failed | incomplete | incomplete | failed | 5578 / 1024 | 17.013 |
| qwen3.8:27b | e2 | reconstructed_exposed | 1 | failed | incomplete | incomplete | failed | 13238 / 1030 | 17.908 |
| qwen3.8:27b | e2 | reconstructed_exposed | 2 | failed | incomplete | incomplete | failed | 12465 / 1033 | 17.852 |
| qwen3.8:27b | f1 | fresh | 0 | failed | incomplete | incomplete | failed | 5605 / 1150 | 18.674 |
| qwen3.8:27b | f1 | fresh | 1 | failed | incomplete | incomplete | failed | 13353 / 1178 | 19.599 |
| qwen3.8:27b | f1 | fresh | 2 | failed | incomplete | incomplete | failed | 7645 / 1182 | 15.435 |
| qwen3.8:27b | f2 | fresh | 0 | failed | incomplete | incomplete | failed | 5602 / 1352 | 20.714 |
| qwen3.8:27b | f2 | fresh | 1 | passed | passed | passed | failed | 11464 / 1412 | 20.629 |
| qwen3.8:27b | f3 | fresh | 0 | failed | incomplete | incomplete | failed | 5701 / 1064 | 17.948 |
| qwen3.8:27b | f3 | fresh | 1 | failed | incomplete | incomplete | failed | 9080 / 1053 | 14.844 |
| qwen3.8:27b | f3 | fresh | 2 | failed | incomplete | incomplete | failed | 9139 / 1059 | 14.955 |
| qwen3.8:27b | f4 | fresh | 0 | failed | incomplete | incomplete | failed | 5620 / 840 | 14.905 |
| qwen3.8:27b | f4 | fresh | 1 | failed | incomplete | incomplete | failed | 8102 / 904 | 12.399 |
| qwen3.8:27b | f4 | fresh | 2 | failed | incomplete | incomplete | failed | 7819 / 909 | 12.154 |
| qwen3.8:27b | f5 | fresh | 0 | failed | incomplete | incomplete | failed | 5686 / 866 | 15.441 |
| qwen3.8:27b | f5 | fresh | 1 | failed | incomplete | incomplete | failed | 9764 / 855 | 12.965 |
| qwen3.8:27b | f5 | fresh | 2 | failed | incomplete | incomplete | failed | 8162 / 855 | 11.980 |
| qwen3.8:27b | f6 | fresh | 0 | failed | incomplete | incomplete | failed | 5655 / 1142 | 18.441 |
| qwen3.8:27b | f6 | fresh | 1 | failed | incomplete | incomplete | failed | 12254 / 1164 | 18.586 |
| qwen3.8:27b | f6 | fresh | 2 | failed | incomplete | incomplete | failed | 11895 / 1162 | 18.655 |
| qwen3.8:27b | r1 | reduction_repeat | 0 | failed | incomplete | incomplete | failed | 2366 / 953 | 14.112 |
| qwen3.8:27b | r1 | reduction_repeat | 1 | failed | incomplete | incomplete | failed | 6880 / 956 | 14.414 |
| qwen3.8:27b | r1 | reduction_repeat | 2 | failed | incomplete | incomplete | failed | 6016 / 981 | 14.198 |
| qwen3.8:27b | r2 | reduction_repeat | 0 | failed | incomplete | incomplete | failed | 2447 / 660 | 11.220 |
| qwen3.8:27b | r2 | reduction_repeat | 1 | failed | incomplete | incomplete | failed | 5189 / 682 | 10.244 |
| qwen3.8:27b | r2 | reduction_repeat | 2 | failed | incomplete | incomplete | failed | 4103 / 688 | 9.509 |
