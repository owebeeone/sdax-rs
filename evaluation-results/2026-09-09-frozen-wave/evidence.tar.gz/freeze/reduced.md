## Types and ownership

`Plan<Out, In>` takes one `In` at each root start, static mount, or dynamic
spawn and may export completed `Out`. Call `p.export(key)` before `build`;
merely declaring the last step does not select an output.

`Key<T>` is a typed declaration handle. A body that `.needs(key)` receives
`Arc<T>`. A body that `.needs((a, b))` receives `(Arc<A>, Arc<B>)`, while one
`Key<(A, B)>` produces `Arc<(A, B)>`. Return plain `T` from steps and service
initializers. Resource acquisition and effect performance return `Held<T>`.
Returning `Arc<T>` from an ordinary step deliberately makes its node
`Key<Arc<T>>`, so dependents receive `Arc<Arc<T>>`.

Both `cx.hold(factory).await` and `cx.hold_value(value)` consume the single-use
`Cx<Acquire>`. Put an external acquisition inside the lazy `hold` factory.
`hold_value` is for a value already owned without an external action. Both
accept an existing `Arc<T>` without nesting it, and expected `Held<T>` can use
an unsized `T`, such as `dyn Trait + Send + Sync`. Save `let shared =
cx.shared()` first if later code needs cancellation or clock operations.

A tuple or struct containing `Arc<Resource>` is ordinary data; it does not
create a visible cleanup dependency. Pass ordinary request data through the
plan input. For a parent-owned resource, declare `child.port::<T>(name)`, bind
it with `child.bind(port, parent_resource_key)`, and make every child resource
that uses it name the port in `.needs(...)`.

## Retry, effects, and services

Two total attempts is `.idempotent().retry(Retry::attempts(2))`. Do not loop
around or clone an acquisition context; each attempt receives fresh authority.

Choose one ambiguity value, such as `Ambiguity::Report`, then finish an effect
with `.compensate(...)` or `.persistent()`:

```rust
p.effect("write")
    .needs(config)
    .on_ambiguous(Ambiguity::Report)
    .perform(|cx, value: Arc<u64>| async move { Ok(cx.hold_value(*value)) })
    .compensate(|_cx, _receipt: Arc<u64>| async move { Ok(()) });
```

For `Ambiguity::Recover`, put `.needs(...)` before
`.identified_by(identity_key)`, then `.perform(...)` and
`.recover_unknown(...)`. The chain is still unfinished: terminate it with
`.compensate(...)` or `.persistent()`. Perform receives
`(ordinary_dependencies, Arc<Identity>)`; recovery receives only
`Arc<Identity>`. Domain recovery errors can display an operation ID, while a
generic still-unknown record cannot promise to format arbitrary identity data.

A resident service uses the same initialized `Arc<H>` for every serving
episode. `Retry` controls initialization; `Restart` controls later episodes:

```rust
p.service("accept")
    .idempotent()
    .restart(Restart::on_error(Backoff::fixed(Duration::from_secs(1))).max(2))
    .stop_within(Duration::from_secs(2))
    .initialize(|_cx, ()| async { Ok(()) })
    .serve(|cx, _handle: Arc<()>| async move {
        if cx.episode() == 1 {
            Err::<(), Error>("disconnected".into())
        } else {
            cx.stop().await;
            Ok(())
        }
    });
```

A restart does not rerun successful initialization or dependents. Use
`cx.spawn` for declared templates rather than launching untracked tasks.
