use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;
use std::time::Duration;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut parent = Plan::builder("parent");
    let base_val = parent.input();

    // Parent opens base value n
    let base_res: Key<Resource> = parent
        .resource("base")
        .acquire(move |cx, n: Arc<u32>| {
            let env = env.clone();
            async move {
                let r = env.open("base", *n, &[]).await?;
                Ok(cx.hold_value(r))
            }
        })
        .release(move |cx, r: Arc<Resource>| {
            let env = env.clone();
            async move {
                env.close(&r).await?;
                Ok(())
            }
        });

    // Define child component
    let (child, base_port) = child_component(env.clone());

    // Bind child's formal resource port to parent's base
    let bound = child.bind(base_port, base_res).expect("base binding");

    // Mount child with offset 7
    let child_input = parent.step("offset").run(move |_cx, n: Arc<u32>| {
        let offset = 7;
        async move { Ok(n + offset) }
    });

    let child_output = parent.component("child_mount", &bound, child_input);

    // Export derived.value
    let output = parent.step("export").needs(child_output).run(
        |_cx, val: Arc<u32>| async move { Ok(*val) },
    );

    build(parent.export(output))
}

fn child_component(env: Env) -> (Plan<u32, u32>, Key<Resource>) {
    let mut child = Plan::with_input::<u32>("child");
    let input = child.input();
    let base_port: Key<Resource> = child.port::<Resource>("base");

    // rates: needs base, fails first attempt with "transient rates"
    let rates: Key<Resource> = child
        .resource("rates")
        .needs((input, base_port))
        .idempotent()
        .retry(Retry::attempts(2).with_backoff(Backoff::fixed(Duration::from_millis(1))))
        .acquire(move |cx, (input, base): (Arc<u32>, Arc<Resource>)| {
            let env = env.clone();
            async move {
                env.record(format!("attempt:rates:{}", cx.attempt()));
                if cx.attempt() == 1 {
                    Err("transient rates".into())
                } else {
                    let val = base.value + input;
                    let r = env.open("rates", val, &[base]).await?;
                    Ok(cx.hold_value(r))
                }
            }
        })
        .release(move |cx, r: Arc<Resource>| {
            let env = env.clone();
            async move {
                env.close(&r).await?;
                Ok(())
            }
        });

    // derived: needs base and rates
    let derived: Key<Resource> = child
        .resource("derived")
        .needs((input, base_port, rates))
        .acquire(move |cx, (input, base, rates): (Arc<u32>, Arc<Resource>, Arc<Resource>)| {
            let env = env.clone();
            async move {
                let val = rates.value; // derived.value is rates.value (which is base+offset)
                let r = env.open("derived", val, &[base, &rates]).await?;
                Ok(cx.hold_value(r))
            }
        })
        .release(move |cx, r: Arc<Resource>| {
            let env = env.clone();
            async move {
                // Note: The prompt implies derived cleanup failure is injected via Env.fail
                // which is handled by Env::close.
                env.close(&r).await?;
                Ok(())
            }
        });

    let output = child
        .step("final_val")
        .needs(derived)
        .run(|_cx, r: Arc<Resource>| async move { Ok(r.value) });

    (build(child.export(output)), base_port)
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report
        .into_result()
        .map_err(|r| r.to_string())?
        .as_deref()
        .copied()
        .ok_or_else(|| "missing output".to_string())
}
