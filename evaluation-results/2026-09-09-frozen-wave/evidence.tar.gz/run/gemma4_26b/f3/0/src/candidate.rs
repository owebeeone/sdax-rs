use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;
use std::time::Duration;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut p = Plan::builder("candidate");

    // Step 1: Permit acquisition
    // Input n opens permit value n.
    let permit = p.resource("permit")
        .idempotent()
        .acquire(move |cx, n: u32| {
            let env = env.clone();
            async move {
                let res = env.open("permit", n, &[]).await?;
                Ok(cx.hold_value(res))
            }
        })
        .release(move |cx, res: Arc<Resource>| {
            let env = env.clone();
            async move {
                env.close(res.as_ref()).await?;
                Ok(())
            }
        });

    // Step 2: Identity declaration
    // Per-run identity u32 n*100+17
    let identity = p.step("identity")
        .run(move |_cx, n: u32| async move {
            Ok(n * 100 + 17)
        });

    // Step 3: The effectful 'send'
    // 3 total attempts, 1ms backoff, 4ms deadline, unknown-outcome recovery.
    // send:<attempt>:<identity>:<permit.value>:<identity-Arc-pointer>
    let send = p.effect("send")
        .needs((identity, permit))
        .identified_by(identity.clone())
        .idempotent()
        .retry(Retry::attempts(2))
        .on_ambiguous(Ambiguity::Recover)
        .perform(|cx, (id, permit): (Arc<u32>, Arc<Resource>)| {
            let env = env.clone();
            let id_ptr = Arc::as_ptr(&id) as usize;
            let p_val = permit.value;
            let id_val = *id;
            async move {
                let attempt = cx.attempt();
                env.record(format!("{}:{}:{}:{}:{}", attempt, id_val, p_val, id_ptr));
                
                // Attempt 1 and 2 return known errors.
                // Attempt 3 remains pending (simulated by a long sleep or logic).
                if attempt <= 2 {
                    return Err::<(), Error>("known error".into());
                }
                
                // To simulate "remains pending without receipt" for attempt 3:
                // We don't return Ok or Err here, we just hang or wait for recovery.
                // However, the engine needs a result to trigger recovery.
                // In sdax, recovery is triggered when the effect is "ambiguous".
                // Since we can't literally hang the executor forever in a way that 
                // allows recovery to run, we simulate the "unknown" state.
                Err::<(), Error>("unknown outcome".into())
            }
        })
        .recover_unknown(|cx, id: Arc<u32>| {
            let env = env.clone();
            let id_val = *id;
            async move {
                // MUST run while permit remains live.
                // Check live_count == 1 (only permit is live)
                if env.live_count() != 1 {
                    return Err::<(), Error>("wrong live count".into());
                }
                env.record("permit-live-at-recovery");
                
                // To exercise check: open audit and close it before permit release.
                let audit = env.open("audit", id_val, &[]).await?;
                env.close(&audit).await?;
                
                env.record(format!("recover:{}:{}", cx.attempt(), id_val));
                Ok(cx.hold_value(id_val))
            }
        })
        .compensate(|_cx, _receipt: Arc<u32>| async move {
            // Compensation must not run per requirements (it's not called if recovered).
            Ok(())
        });

    // Step 4: Independent completed n+1 data step.
    let output = p.step("output")
        .needs(send)
        .run(|_cx, val: Arc<u32>| async move {
            Ok(*val + 1)
        });

    p.build(
        Policy::FailFast,
        Shutdown::within(Duration::from_secs(1)),
        Mode::Finite,
    ).expect("valid plan")
        .export(output)
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report.into_result()
        .map_err(|r| r.to_string())?
        .as_deref()
        .copied()
        .ok_or_else(|| "missing completed output".to_string())
}
