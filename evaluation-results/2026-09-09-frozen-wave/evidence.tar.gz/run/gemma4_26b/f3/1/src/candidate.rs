use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;
use std::time::Duration;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut p = Plan::builder("candidate");

    // Step 1: Permit acquisition
    // Input n opens permit value n.
    let permit = p.resource("permit")
        .idempotent()
        .acquire(move |cx: Cx<Acquire>, n: u32| {
            let env = env.clone();
            async move {
                let res = env.open("permit", n, &[]).await?;
                Ok(cx.hold_value(res))
            }
        })
        .release(move |cx: Cx<Release>, res: Arc<crate::support::Resource>| {
            let env = env.clone();
            async move {
                env.close(res.as_ref()).await?;
                Ok(())
            }
        });

    // Step 2: Identity declaration
    // Per-run identity u32 n*100+17
    let identity = p.step("identity")
        .run(move |_cx, n: u32| async move {
            Ok(n * 100 + 17)
        });

    // Step 3: The effectful 'send'
    // 3 total attempts, 1ms backoff, 4ms deadline, unknown-outcome recovery.
    // send:<attempt>:<identity>:<permit.value>:<identity-Arc-pointer>
    let send = p.effect("send")
        .needs((identity.clone(), permit.clone()))
        .on_ambiguous(Ambiguity::Recover)
        .identified_by(identity.clone())
        .idempotent()
        .retry(Retry::attempts(2))
        .perform(|cx, (id, permit): (Arc<u32>, Arc<crate::support::Resource>)| {
            let env = env.clone();
            let id_ptr = Arc::as_ptr(&id) as usize;
            let p_val = permit.value;
            let id_val = *id;
            async move {
                let attempt = cx.attempt();
                env.record(format!("{}:{}:{}:{}:{}", attempt, id_val, p_val, id_ptr));
                
                if attempt <= 2 {
                    return Err::<(), Error>("known error".into());
                }
                
                // Simulate unknown outcome for attempt 3
                Err::<(), Error>("unknown outcome".into())
            }
        })
        .recover_unknown(|cx, id: Arc<u32>| {
            let env = env.clone();
            let id_val = *id;
            async move {
                if env.live_count() != 1 {
                    return Err::<(), Error>("wrong live count".into());
                }
                env.record("permit-live-at-recovery");
                
                let audit = env.open("audit", id_val, &[]).await?;
                env.close(&audit).await?;
                
                env.record(format!("recover:{}:{}", cx.attempt(), id_val));
                Ok(cx.hold_value(id_val))
            }
        })
        .compensate(|_cx, _receipt: Arc<u32>| async move {
            Ok(())
        });

    // Step 4: Independent completed n+1 data step.
    let output = p.step("output")
        .needs(send)
        .run(|_cx, val: Arc<u32>| async move {
            Ok(*val + 1)
        });

    p.export(output).build(
        Policy::FailFast,
        Shutdown::within(Duration::from_secs(1)),
        Mode::Finite,
    ).expect("valid plan")
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report.into_result()
        .map_err(|r| r.to_string())?
        .as_deref()
        .copied()
        .ok_or_else(|| "missing completed output".to_string())
}
