use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;

#[derive(Debug)]
struct Report<T>(Result<Arc<T>, String>);

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut p = Plan::new();

    // Root input n opens west (n+1) and east (n+4)
    let west_key = p.effect("west_open")
        .perform(|cx, n: u32| async move {
            let res = cx.env().open("west", n + 1, &[]).await?;
            Ok(cx.hold_value(res))
        })
        .idempotent()
        .retry(Retry::attempts(2));

    let east_key = p.effect("east_open")
        .perform(|cx, n: u32| async move {
            let res = cx.env().open("east", n + 4, &[]).await?;
            Ok(cx.hold_value(res))
        })
        .idempotent()
        .retry(Retry::attempts(2));

    // The "child" template: takes bias and two resource ports
    // It opens a resource named slot-<bias>
    let child = |bias: u32| {
        let mut cp = Plan::new();
        let slot_name = format!("slot-{}", bias);
        
        cp.effect("encode")
            .port::<Resource>("tens")
            .port::<Resource>("units")
            .perform(move |cx, (tens, units): (Arc<Resource>, Arc<Resource>)| async move {
                let val = 10 * tens.value + units.value + bias;
                // Must name the resource slot-<bias>
                // Parents are the formal ports
                let res = cx.env().open(&slot_name, val, &[&tens, &units]).await?;
                Ok(cx.hold_value(res))
            })
            .idempotent()
            .retry(Retry::attempts(2))
            // Ensure the resource is closed before the parents
            .on_ambiguous(Ambiguity::Report)
            .compensate(move |cx, res: Arc<Resource>| async move {
                cx.env().close(&res).await?;
                Ok(())
            })
            .persistent();
        
        // We need to export the value from the resource
        let mut cp_out = Plan::new();
        cp_out.effect("extract")
            .needs(cp.effect("encode"))
            .perform(|cx, res: Arc<Resource>| async move {
                Ok(cx.hold_value(res.value))
            })
            .persistent();
        
        cp_out
    };

    // Mount Low: tens=west, units=east, bias=2
    let low_plan = child(2);
    let low_key = p.spawn(low_plan)
        .bind::<Resource>("tens", west_key)
        .bind::<Resource>("units", east_key);

    // Mount High: tens=east, units=west, bias=5
    let high_plan = child(5);
    let high_key = p.spawn(high_plan)
        .bind::<Resource>("tens", east_key)
        .bind::<Resource>("units", west_key);

    // Final aggregation: low*1000 + high
    p.effect("aggregate")
        .needs((low_key, high_key))
        .perform(|_cx, (low, high): (Arc<u32>, Arc<u32>)| async move {
            Ok(cx.hold_value(low * 1000 + high))
        })
        .persistent();

    p.export(p.effect("aggregate"));
    p
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    match report.0 {
        Ok(val) => Ok((*val).clone()),
        Err(e) => Err(e),
    }
}

impl<T> From<Result<Arc<T>, String>> for Report<T> {
    fn from(r: Result<Arc<T>, String>) -> Self {
        Report(r)
    }
}
