use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;

// Disambiguate Resource from glob imports
use crate::support::Resource as SupportResource;

#[derive(Debug)]
pub struct Report<T>(pub Result<Arc<T>, String>);

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut p = Plan::default();

    // Root input n opens west (n+1) and east (n+4)
    let west_key = p.effect("west_open")
        .perform(|cx, n: u32| async move {
            let res = cx.env().open("west", n + 1, &[]).await?;
            Ok(cx.hold_value(res))
        })
        .idempotent()
        .retry(Retry::attempts(2));

    let east_key = p.effect("east_open")
        .perform(|cx, n: u32| async move {
            let res = cx.env().open("east", n + 4, &[]).await?;
            Ok(cx.hold_value(res))
        })
        .idempotent()
        .retry(Retry::attempts(2));

    // The "child" template
    let child = |bias: u32| {
        let mut cp = Plan::default();
        let slot_name = format!("slot-{}", bias);
        
        let encode_key = cp.effect("encode")
            .port::<SupportResource>("tens")
            .port::<SupportResource>("units")
            .perform(move |cx, (tens, units): (Arc<SupportResource>, Arc<SupportResource>)| async move {
                let val = 10 * tens.value + units.value + bias;
                let res = cx.env().open(&slot_name, val, &[&tens, &units]).await?;
                Ok(cx.hold_value(res))
            })
            .idempotent()
            .retry(Retry::attempts(2))
            .on_ambiguous(Ambiguity::Report)
            .compensate(move |cx, res: Arc<SupportResource>| async move {
                cx.env().close(&res).await?;
                Ok(())
            })
            .persistent();

        let mut cp_out = Plan::default();
        cp_out.effect("extract")
            .needs(encode_key)
            .perform(|cx, res: Arc<SupportResource>| async move {
                Ok(cx.hold_value(res.value))
            })
            .persistent();
        
        cp_out
    };

    // Mount Low: tens=west, units=east, bias=2
    let low_plan = child(2);
    let low_key = p.spawn(low_plan)
        .bind::<SupportResource>("tens", west_key)
        .bind::<SupportResource>("units", east_key);

    // Mount High: tens=east, units=west, bias=5
    let high_plan = child(5);
    let high_key = p.spawn(high_plan)
        .bind::<SupportResource>("tens", east_key)
        .bind::<SupportResource>("units", west_key);

    // Final aggregation: low*1000 + high
    let agg_key = p.effect("aggregate")
        .needs((low_key, high_key))
        .perform(|cx, (low, high): (Arc<u32>, Arc<u32>)| async move {
            Ok(cx.hold_value((*low) * 1000 + (*high)))
        })
        .persistent();

    p.export(agg_key);
    p
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    match report.0 {
        Ok(val) => Ok((*val).clone()),
        Err(e) => Err(e),
    }
}

impl<T> From<Result<Arc<T>, String>> for Report<T> {
    fn from(r: Result<Arc<T>, String>) -> Self {
        Report(r)
    }
}
