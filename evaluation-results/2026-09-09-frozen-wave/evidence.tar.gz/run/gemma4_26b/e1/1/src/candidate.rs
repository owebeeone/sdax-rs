use crate::support::{Env, Resource};
use sdax::prelude::*;
use std::sync::Arc;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut p = Plan::with_input::<u32>("input");
    let input = p.input();

    let base_env = env.clone();
    let base: Key<Resource> = p
        .resource("base")
        .acquire(move |cx: Cx<Acquire>, val: Arc<u32>| {
            let env = base_env.clone();
            async move {
                let r = env.open("base", *val, &[]).await?;
                Ok(cx.hold_value(r))
            }
        })
        .release(move |cx: Cx<Release>, r: Arc<Resource>| {
            let env = base_env.clone();
            async move {
                env.close(&r).await?;
                Ok(())
            }
        });

    let derived_env = env.clone();
    let derived: Key<Resource> = p
        .resource("derived")
        .needs((input, base))
        .acquire(move |cx: Cx<Acquire>, (val, base_res): (Arc<u32>, Arc<Resource>)| {
            let env = derived_env.clone();
            async move {
                let r = env.open("derived", base_res.value + 5, &[&*base_res]).await?;
                Ok(cx.hold_value(r))
            }
        })
        .release(move |cx: Cx<Release>, r: Arc<Resource>| {
            let env = derived_env.clone();
            async move {
                env.close(&r).await?;
                Ok(())
            }
        });

    let completed = p
        .step("completed")
        .needs(derived)
        .run(|_cx: Cx<Run>, r: Arc<Resource>| async move { Ok(r.value * 2) });

    p.export(completed).build(
        Policy::FailFast,
        sdax::Shutdown::within(std::time::Duration::from_secs(1)),
        sdax::Mode::Finite,
    )
    .expect("valid plan")
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report
        .into_result()
        .map_err(|r| r.to_string())?
        .as_deref()
        .copied()
        .ok_or_else(|| "missing completed output".to_string())
}
