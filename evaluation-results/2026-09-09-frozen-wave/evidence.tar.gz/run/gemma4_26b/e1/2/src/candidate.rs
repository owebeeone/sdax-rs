use crate::support::{Env, Resource};
use sdax::prelude::*;
use std::sync::Arc;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut p = Plan::with_input::<u32>("input");
    let input = p.input();

    let base_env = env.clone();
    let base: Key<Resource> = p
        .resource("base")
        .acquire(move |cx: Cx<Acquire>, (): ()| {
            let env = base_env.clone();
            // We need to capture the input value. Since 'base' has no dependencies,
            // we must use a step to bring the input into scope or use a different approach.
            // However, the prompt implies 'base' is the first resource.
            // To access 'input' in 'base', 'base' must depend on 'input'.
            // But 'base' is a resource, and the error shows it expects () as D::Out.
            // We will use a step to provide the value to the resource acquisition.
            // Actually, the simplest way to satisfy the signature is to make 'base' 
            // depend on 'input' so its D::Out is Arc<u32>.
            // Wait, the error says: expected fn(Cx<Acquire>, ()) -> _
            // This means the node 'base' currently has no dependencies.
            // Let's add 'input' to 'base' dependencies.
            async move {
                // This is a placeholder; the actual logic is moved to the corrected dependency chain below.
                Ok(cx.hold_value(Resource { value: 0, name: "".into() }))
            }
        })
        .release(move |cx: Cx<Release>, r: Arc<Resource>| {
            let env = base_env.clone();
            async move {
                env.close(&r).await?;
                Ok(())
            }
        });

    // Re-implementing with correct dependency logic to satisfy the compiler and the prompt.
    let mut p = Plan::with_input::<u32>("input");
    let input = p.input();

    let base_env = env.clone();
    let base: Key<Resource> = p
        .resource("base")
        .needs(input)
        .acquire(move |cx: Cx<Acquire>, val: Arc<u32>| {
            let env = base_env.clone();
            async move {
                let r = env.open("base", *val, &[]).await?;
                Ok(cx.hold_value(r))
            }
        })
        .release(move |cx: Cx<Release>, r: Arc<Resource>| {
            let env = base_env.clone();
            async move {
                env.close(&r).await?;
                Ok(())
            }
        });

    let derived_env = env.clone();
    let derived: Key<Resource> = p
        .resource("derived")
        .needs((input, base))
        .acquire(move |cx: Cx<Acquire>, (val, base_res): (Arc<u32>, Arc<Resource>)| {
            let env = derived_env.clone();
            async move {
                let r = env.open("derived", base_res.value + 5, &[&*base_res]).await?;
                Ok(cx.hold_value(r))
            }
        })
        .release(move |cx: Cx<Release>, r: Arc<Resource>| {
            let env = derived_env.clone();
            async move {
                env.close(&r).await?;
                Ok(())
            }
        });

    let completed = p
        .step("completed")
        .needs(derived)
        .run(|_cx: Cx<Run>, r: Arc<Resource>| async move { Ok(r.value * 2) });

    p.export(completed).build(
        Policy::FailFast,
        sdax::Shutdown::within(std::time::Duration::from_secs(1)),
        sdax::Mode::Finite,
    )
    .expect("valid plan")
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report
        .into_result()
        .map_err(|r| r.to_string())?
        .as_deref()
        .copied()
        .ok_or_else(|| "missing completed output".to_string())
}
