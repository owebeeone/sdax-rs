use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut root = Plan::with_input::<u32>("root");
    let input_key: Key<u32> = root.input();

    // Root component: opens vault
    let vault_res: Key<crate::support::Resource> = root
        .resource("vault")
        .needs(input_key)
        .acquire(move |cx, n| {
            let env = env.clone();
            let input = n.clone();
            async move {
                let val = (*input) * 3;
                let r = env.open("vault", val, &[]).await?;
                Ok(cx.hold_value(r))
            }
        })
        .release(move |cx, r| {
            let env = env.clone();
            async move {
                env.close(&r).await?;
                Ok(())
            }
        });

    // Middle component: accepts tuple and vault
    let (middle_plan, middle_vault_port) = middle_component(&mut root, &vault_res);
    let middle_input = root.step("middle input").run(move |_, n| async move {
        let val = *n;
        Ok((val + 2, val + 5))
    });
    let middle_output = root.component("middle", &middle_plan, middle_input);

    // Export middle output
    root.export(middle_output).build(
        Policy::FailFast,
        Shutdown::within(std::time::Duration::from_secs(10)),
        Mode::Finite,
    ).expect("valid plan")
}

fn middle_component<'a>(
    parent: &'a mut PlanBuilder<u32, u32>,
    vault_key: &Key<crate::support::Resource>,
) -> (Plan<u32, (u32, u32)>, Key<crate::support::Resource>) {
    let mut child = Plan::with_input::<(u32, u32)>("middle");
    let input_key: Key<(u32, u32)> = child.input();
    let vault_port: Key<crate::support::Resource> = child.port::<crate::support::Resource>("vault");

    // Middle resource: opens sleeve
    let sleeve_res: Key<crate::support::Resource> = child
        .resource("sleeve")
        .needs((input_key, vault_port.clone()))
        .acquire(move |cx, (input, vault)| async move {
            let env = cx.shared().env().clone();
            let val = vault.value + input.0;
            let r = env.open("sleeve", val, &[vault]).await?;
            Ok(cx.hold_value(r))
        })
        .release(move |cx, r| {
            let env = cx.shared().env().clone();
            async move {
                env.close(&r).await?;
                Ok(())
            }
        });

    // Leaf component: opens lens
    let (leaf_plan, leaf_sleeve_port) = leaf_component(&mut child, &sleeve_res);
    let leaf_input = child.step("leaf input").run(|_, input| async move {
        Ok(input.1)
    });
    let leaf_output = child.component("leaf", &leaf_plan, leaf_input);

    let exported = child.export(leaf_output).build(
        Policy::FailFast,
        Shutdown::within(std::time::Duration::from_secs(10)),
        Mode::Finite,
    ).expect("valid plan");

    (exported, vault_port.clone())
}

fn leaf_component<'a>(
    parent: &'a mut PlanBuilder<u32, u32>,
    sleeve_key: &Key<crate::support::Resource>,
) -> (Plan<u32, u32>, Key<crate::support::Resource>) {
    let mut child = Plan::with_input::<u32>("leaf");
    let input_key: Key<u32> = child.input();
    let sleeve_port: Key<crate::support::Resource> = child.port::<crate::support::Resource>("sleeve");

    let lens_res: Key<crate::support::Resource> = child
        .resource("lens")
        .needs((input_key, sleeve_port.clone()))
        .acquire(move |cx, (input, sleeve)| async move {
            let env = cx.shared().env().clone();
            let val = sleeve.value * 2 + *input;
            let r = env.open("lens", val, &[sleeve]).await?;
            Ok(cx.hold_value(r))
        })
        .release(move |cx, r| {
            let env = cx.shared().env().clone();
            async move {
                env.close(&r).await?;
                Ok(())
            }
        });

    let output = child
        .step("lens output")
        .needs(lens_res)
        .run(|_, r| async move { Ok(r.value) });

    let exported = child.export(output).build(
        Policy::FailFast,
        Shutdown::within(std::time::Duration::from_secs(10)),
        Mode::Finite,
    ).expect("valid plan");

    (exported, sleeve_port.clone())
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report
        .into_result()
        .map_err(|r| r.to_string())?
        .as_deref()
        .copied()
        .ok_or_else(|| "missing completed output".to_string())
}
