use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut root = Plan::with_input::<u32>("root");
    let input_key: Key<u32> = root.input();

    // Root component: opens vault
    let vault_res: Key<Resource> = root
        .resource("vault")
        .needs(input_key)
        .acquire(move |cx, n| {
            let env = env.clone();
            let input = n.clone();
            async move {
                let val = (*input) * 3;
                let r = env.open("vault", val, &[]).await?;
                Ok(cx.hold_value(r))
            }
        })
        .release(move |cx, r| {
            let env = env.clone();
            async move {
                env.close(r).await?;
                Ok(())
            }
        });

    // Middle component: accepts tuple and vault
    let (middle_plan, middle_vault_port) = middle_component(&mut root, &vault_res);
    let middle_input = root.step("middle input").run(move |_, n| async move {
        let val = *n;
        Ok((val + 2, val + 5))
    });
    let middle_output = root.component("middle", &middle_vault_port, middle_input);

    // Export middle output
    build_plan(root.export(middle_output))
}

fn middle_component(
    parent: &mut PlanBuilder,
    vault_key: &Key<Resource>,
) -> (Plan<u32, (u32, u32)>, Key<Resource>) {
    let mut child = Plan::with_input::<(u32, u32)>("middle");
    let input_key: Key<(u32, u32)> = child.input();
    let vault_port: Key<Resource> = child.port::<Resource>("vault");

    // Middle resource: opens sleeve
    let sleeve_res: Key<Resource> = child
        .resource("sleeve")
        .needs((input_key, vault_port))
        .acquire(move |cx, (input, vault)| async move {
            let env = cx.env(); // Note: Env is available via cx in some sdax versions, 
                                // but here we assume we must pass it or use the one from build.
                                // Since build provides Env, we rely on the fact that 
                                // the plan structure is built. However, the prompt says 
                                // "Use Env.open inside cx.hold". 
                                // In sdax, cx.env() provides the Env passed to the plan.
            let env = cx.env();
            let val = vault.value + input.0;
            let r = env.open("sleeve", val, &[vault]).await?;
            Ok(cx.hold_value(r))
        })
        .release(move |cx, r| {
            let env = cx.env();
            async move {
                env.close(r).await?;
                Ok(())
            }
        });

    // Leaf component: opens lens
    let (leaf_plan, leaf_sleeve_port) = leaf_component(&mut child, &sleeve_res);
    let leaf_input = child.step("leaf input").run(|_, input| async move {
        Ok(input.1)
    });
    let leaf_output = child.component("leaf", &leaf_sleeve_port, leaf_input);

    (build_plan(child.export(leaf_output)), vault_port)
}

fn leaf_component(
    parent: &mut PlanBuilder,
    sleeve_key: &Key<Resource>,
) -> (Plan<u32, u32>, Key<Resource>) {
    let mut child = Plan::with_input::<u32>("leaf");
    let input_key: Key<u32> = child.input();
    let sleeve_port: Key<Resource> = child.port::<Resource>("sleeve");

    let lens_res: Key<Resource> = child
        .resource("lens")
        .needs((input_key, sleeve_port))
        .acquire(move |cx, (input, sleeve)| async move {
            let env = cx.env();
            let val = sleeve.value * 2 + *input;
            let r = env.open("lens", val, &[sleeve]).await?;
            Ok(cx.hold_value(r))
        })
        .release(move |cx, r| {
            let env = cx.env();
            async move {
                env.close(r).await?;
                Ok(())
            }
        });

    let output = child
        .step("lens output")
        .needs(lens_res)
        .run(|_, r| async move { Ok(r.value) });

    (build_plan(child.export(output)), sleeve_port)
}

fn build_plan<O, I>(p: Plan<O, I>) -> Plan<O, I> {
    p.build(Policy::FailFast, Shutdown::within(std::time::Duration::from_secs(10)), Mode::Finite).expect("valid plan")
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report
        .into_result()
        .map_err(|r| r.to_string())?
        .as_deref()
        .copied()
        .ok_or_else(|| "missing completed output".to_string())
}
