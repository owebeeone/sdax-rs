#[path = "/Users/owebeeone/limbo/sdax-wz/sdax-rs/evaluation-harness/support.rs"]
mod support;
mod candidate;
#[cfg(test)]
#[path = "/Users/owebeeone/limbo/sdax-wz/sdax-rs/evaluation-harness/assertions/f2.rs"]
mod assertions;
