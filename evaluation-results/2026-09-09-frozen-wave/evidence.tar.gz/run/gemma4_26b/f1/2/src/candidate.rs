use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut parent = Plan::builder("encoder_parent");
    let input_key: Key<u32> = parent.input();

    // Root input n opens west (n+1) and east (n+4)
    let west_res = parent.resource("west")
        .needs(input_key)
        .acquire(move |cx, n| {
            let env = env.clone();
            async move {
                let res = env.open("west", *n + 1, &[]).await?;
                Ok(cx.hold_value(res))
            }
        })
        .release(move |cx, res| {
            let env = env.clone();
            async move {
                env.close(&res).await?;
                Ok(())
            }
        });

    let east_res = parent.resource("east")
        .needs(input_key)
        .acquire(move |cx, n| {
            let env = env.clone();
            async move {
                let res = env.open("east", *n + 4, &[]).await?;
                Ok(cx.hold_value(res))
            }
        })
        .release(move |cx, res| {
            let env = env.clone();
            async move {
                env.close(&res).await?;
                Ok(())
            }
        });

    // Reusable child definition
    let (child, tens_port, units_port) = encoder_child_template(env.clone());

    // Mount Low: tens=west, units=east, bias=2
    let low_input = parent.step("low_bias_input").run(|_cx, ()| async move { Ok(2u32) });
    let low_bound = child.bind(tens_port, west_res).expect("bind tens low");
    let low_bound_final = low_bound.bind(units_port, east_res).expect("bind units low");
    let low_exec = parent.component("low_mount", &low_bound_final, low_input);

    // Mount High: tens=east, units=west, bias=5
    let high_input = parent.step("high_bias_input").run(|_cx, ()| async move { Ok(5u32) });
    let high_bound = child.bind(tens_port, east_res).expect("bind tens high");
    let high_bound_final = high_bound.bind(units_port, west_res).expect("bind units high");
    let high_exec = parent.component("high_mount", &high_bound_final, high_input);

    // Final output: low*1000 + high
    let output = parent.step("combine")
        .needs((low_exec, high_exec))
        .run(|_cx, (l, h): (Arc<u32>, Arc<u32>)| async move {
            Ok((*l * 1000) + *h)
        });

    parent.export(output).build(
        Policy::FailFast,
        Shutdown::within(std::time::Duration::from_secs(10)),
        Mode::Finite,
    ).expect("valid plan")
}

fn encoder_child_template(env: Env) -> (Plan<u32, u32>, Key<crate::support::Resource>, Key<crate::support::Resource>) {
    let mut child = Plan::with_input::<u32>("encoder_child");
    let bias_input = child.input();
    let tens_port: Key<crate::support::Resource> = child.port("tens");
    let units_port: Key<crate::support::Resource> = child.port("units");

    let slot_res = child.resource("slot")
        .needs((bias_input, tens_port, units_port))
        .acquire(|cx, (bias, tens, units)| {
            let env = env.clone();
            let bias = *bias;
            let tens = tens.clone();
            let units = units.clone();
            async move {
                let val = 10 * tens.value + units.value + bias;
                let name = format!("slot-{}", bias);
                let res = env.open(&name, val, &[&tens, &units]).await?;
                Ok(cx.hold_value(res))
            }
        })
        .release(move |cx, res| {
            let env = env.clone();
            async move {
                env.close(&res).await?;
                Ok(())
            }
        });

    let output = child.step("output")
        .needs(slot_res)
        .run(|_cx, res: Arc<crate::support::Resource>| async move {
            Ok(res.value)
        });

    (child.export(output).build(
        Policy::FailFast,
        Shutdown::within(std::time::Duration::from_secs(10)),
        Mode::Finite,
    ).expect("valid child"), tens_port, units_port)
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report
        .into_result()
        .map_err(|r| r.to_string())?
        .as_deref()
        .copied()
        .ok_or_else(|| "missing completed output".to_string())
}
