use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut root = Plan::builder("root mount session");
    let input: Key<u32> = root.input();

    // Root opens trunk
    let trunk: Key<Resource> = root
        .resource("trunk")
        .acquire(move |cx, n: Arc<u32>| {
            let env = env.clone();
            async move {
                let r = env.open("trunk", *n, &[]).await?;
                Ok(cx.hold_value(r))
            }
        })
        .release(move |cx, r: Arc<Resource>| {
            let env = env.clone();
            async move {
                env.close(&r).await?;
                Ok(())
            }
        });

    // Middle definition
    let (middle_plan, middle_port) = middle_component(&mut root, trunk.clone(), env.clone());
    let middle_input = root.step("middle input").run(move |_cx, n: Arc<u32>| async move { Ok(n) });
    let middle_output = root.component("middle mount shard", &middle_port, middle_input);

    // Leaf definition
    let (leaf_plan, leaf_port) = leaf_component(&mut root, trunk.clone(), env.clone());
    let leaf_input = root.step("leaf input").run(move |_cx, n: Arc<u32>| async move { Ok(n) });
    let leaf_output = root.component("leaf body aggregate", &leaf_port, leaf_input);

    // Final aggregation
    let output = root
        .step("final aggregate")
        .needs((middle_output, leaf_output))
        .run(|_cx, (m, l): (Arc<u32>, Arc<u32>)| async move {
            Ok((*m + *l) / 2)
        });

    build(root.export(output))
}

fn middle_component(
    p: &mut PlanBuilder,
    trunk: Key<Resource>,
    env: Env,
) -> (Plan<u32, u32>, Key<u32>) {
    let mut child = Plan::with_input::<u32>("middle");
    let input: Key<u32> = child.input();
    let trunk_port: Key<Resource> = child.port::<Resource>("trunk resource");

    let middle_res: Key<u32> = child
        .resource("middle_res")
        .needs((input, trunk_port))
        .acquire(|cx, (input, trunk): (Arc<u32>, Arc<Resource>)| async move {
            Ok(cx.hold_value(trunk.value + *input))
        });

    let output = child.step("middle step").needs(middle_res).run(|_cx, v| async move { Ok(*v) });
    (build(child.export(output)), child.port::<u32>("output_val"))
}

fn leaf_component(
    p: &mut PlanBuilder,
    trunk: Key<Resource>,
    env: Env,
) -> (Plan<u32, u32>, Key<u32>) {
    let mut child = Plan::with_input::<u32>("leaf");
    let input: Key<u32> = child.input();
    let trunk_port: Key<Resource> = child.port::<Resource>("trunk resource");

    let red: Key<Resource> = child
        .resource("red")
        .needs((input, trunk_port.clone()))
        .acquire(move |cx, (input, trunk): (Arc<u32>, Arc<Resource>)| {
            let env = env.clone();
            async move {
                let r = env.open("red", *input + 1, &[trunk]).await?;
                Ok(cx.hold_value(r))
            }
        })
        .release(move |cx, r: Arc<Resource>| {
            let env = env.clone();
            async move {
                env.close(&r).await?;
                Ok(())
            }
        });

    let blue: Key<Resource> = child
        .resource("blue")
        .needs((input, trunk_port))
        .acquire(move |cx, (input, trunk): (Arc<u32>, Arc<Resource>)| {
            let env = env.clone();
            async move {
                let r = env.open("blue", *input + 2, &[trunk]).await?;
                Ok(cx.hold_value(r))
            }
        })
        .release(move |cx, r: Arc<Resource>| {
            let env = env.clone();
            async move {
                env.close(&r).await?;
                Ok(())
            }
        });

    let output = child
        .step("leaf body aggregate")
        .needs((red, blue))
        .run(|_cx, (_red, _blue): (Arc<Resource>, Arc<Resource>)| async move {
            let err = Cause(
                "aggregation refused",
                Some(Box::new(Cause(
                    "checksum mismatch",
                    Some(Box::new(Cause("sector 19", None))),
                ))),
            );
            Err(sdax::Error::from(err))
        });

    (build(child.export(output)), child.port::<u32>("output_val"))
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report.into_result().map_err(|r| {
        let mut s = r.to_string();
        // The requirement asks to ensure specific text is present in the string boundary.
        // Since Report::to_string() is implementation-defined, we rely on the 
        // fact that it must contain the fault and cleanup details.
        s
    })?
    .as_deref()
    .copied()
    .ok_or_else(|| "missing completed output".to_owned())
}
