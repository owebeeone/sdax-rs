use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;

// Disambiguate Resource from sdax::prelude
use crate::support::Resource as SupportResource;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut root = Plan::builder("root mount session");
    let input: Key<u32> = root.input();

    // Root opens trunk
    let trunk: Key<SupportResource> = root
        .resource("trunk")
        .needs(input.clone())
        .acquire(move |cx, n: Arc<u32>| {
            let env = env.clone();
            async move {
                let r = env.open("trunk", *n, &[]).await?;
                Ok(cx.hold_value(r))
            }
        })
        .release(move |cx, r: Arc<SupportResource>| {
            let env = env.clone();
            async move {
                env.close(&r).await?;
                Ok(())
            }
        });

    // Middle definition
    let (middle_plan, middle_port) = middle_component(&mut root, trunk.clone(), env.clone());
    let middle_input = root.step("middle input").run(move |_cx, ()| async move { Ok(()) });
    // The input to middle is actually the scalar n from root input
    let middle_input_val = root.step("middle input val").needs(input.clone()).run(|_cx, n| async move { Ok(*n) });
    let middle_output = root.component("middle mount shard", &middle_plan, middle_input_val);

    // Leaf definition
    let (leaf_plan, leaf_port) = leaf_component(&mut root, trunk.clone(), env.clone());
    let leaf_input_val = root.step("leaf input val").needs(input.clone()).run(|_cx, n| async move { Ok(*n) });
    let leaf_output = root.component("leaf body aggregate", &leaf_plan, leaf_input_val);

    // Final aggregation
    let output = root
        .step("final aggregate")
        .needs((middle_output, leaf_output))
        .run(|_cx, (m, l): (Arc<u32>, Arc<u32>)| async move {
            Ok((*m + *l) / 2)
        });

    root.export(output).build(
        Policy::Isolate,
        Shutdown::within(std::time::Duration::from_secs(5)),
        Mode::Finite,
    ).expect("valid plan")
}

fn middle_component(
    _p: &mut PlanBuilder,
    _trunk: Key<SupportResource>,
    _env: Env,
) -> (Plan<u32, u32>, Key<u32>) {
    let mut child = Plan::with_input::<u32>("middle");
    let input: Key<u32> = child.input();
    let trunk_port: Key<SupportResource> = child.port::<SupportResource>("trunk resource");

    let middle_res: Key<u32> = child
        .resource("middle_res")
        .needs((input.clone(), trunk_port.clone()))
        .acquire(|cx, (input, trunk): (Arc<u32>, Arc<SupportResource>)| async move {
            Ok(cx.hold_value(trunk.value + *input))
        })
        .release(|_cx, _v: Arc<u32>| async move { Ok(()) });

    let output = child.step("middle step").needs(middle_res).run(|_cx, v| async move { Ok(*v) });
    (child.export(output).build(Policy::Isolate, Shutdown::within(std::time::Duration::from_secs(5)), Mode::Finite).expect("valid"), child.port::<u32>("output_val"))
}

fn leaf_component(
    _p: &mut PlanBuilder,
    _trunk: Key<SupportResource>,
    env: Env,
) -> (Plan<u32, u32>, Key<u32>) {
    let mut child = Plan::with_input::<u32>("leaf");
    let input: Key<u32> = child.input();
    let trunk_port: Key<SupportResource> = child.port::<SupportResource>("trunk resource");

    let red: Key<SupportResource> = child
        .resource("red")
        .needs((input.clone(), trunk_port.clone()))
        .acquire(move |cx, (input, trunk): (Arc<u32>, Arc<SupportResource>)| {
            let env = env.clone();
            async move {
                let r = env.open("red", *input + 1, &[trunk.as_ref()]).await?;
                Ok(cx.hold_value(r))
            }
        })
        .release(move |cx, r: Arc<SupportResource>| {
            let env = env.clone();
            async move {
                env.close(&r).await?;
                Ok(())
            }
        });

    let blue: Key<SupportResource> = child
        .resource("blue")
        .needs((input.clone(), trunk_port.clone()))
        .acquire(move |cx, (input, trunk): (Arc<u32>, Arc<SupportResource>)| {
            let env = env.clone();
            async move {
                let r = env.open("blue", *input + 2, &[trunk.as_ref()]).await?;
                Ok(cx.hold_value(r))
            }
        })
        .release(move |cx, r: Arc<SupportResource>| {
            let env = env.clone();
            async move {
                env.close(&r).await?;
                Ok(())
            }
        });

    let output = child
        .step("leaf body aggregate")
        .needs((red, blue))
        .run(|_cx, (_red, _blue): (Arc<SupportResource>, Arc<SupportResource>)| async move {
            let err = Cause(
                "aggregation refused",
                Some(Box::new(Cause(
                    "checksum mismatch",
                    Some(Box::new(Cause("sector 19", None))),
                ))),
            );
            Err(sdax::Error::from(err))
        });

    (child.export(output).build(Policy::Isolate, Shutdown::within(std::time::Duration::from_secs(5)), Mode::Finite).expect("valid"), child.port::<u32>("output_val"))
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report.into_result().map_err(|r| r.to_string())?
        .as_deref()
        .copied()
        .ok_or_else(|| "missing completed output".to_owned())
}

// Helper to allow Arc<T> to be used as &T for Env::open
trait AsRefResource {
    fn as_ref(&self) -> &SupportResource;
}
impl AsRefResource for SupportResource {
    fn as_ref(&self) -> &SupportResource { self }
}
impl AsRefResource for Arc<SupportResource> {
    fn as_ref(&self) -> &SupportResource { self.as_ref() }
}
