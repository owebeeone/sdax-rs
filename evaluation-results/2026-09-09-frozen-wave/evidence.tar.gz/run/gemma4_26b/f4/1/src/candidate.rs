use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;
use std::time::Duration;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut parent = Plan::builder("root");
    let input = parent.input();

    let left_input = parent.step("left_input").run(move |_cx, i| async move {
        Ok(i & !1)
    });

    let right_input = parent.step("right_input").run(move |_cx, i| async move {
        Ok(i | 1)
    });

    let left_child = parent.component("left", &child_template(&env), left_input);
    let right_child = parent.component("right", &child_template(&env), right_input);

    let output = parent
        .step("sum")
        .needs((left_child, right_child))
        .run(|_cx, (l, r)| async move { Ok((*l + *r) / 2) });

    parent.export(output).build(
        Policy::Isolate,
        Shutdown::within(Duration::from_secs(5)),
        Mode::Finite,
    ).expect("valid plan")
}

fn child_template(env: &Env) -> Plan<u32, u32> {
    let mut child = Plan::with_input::<u32>("child");
    let input = child.input();
    let env_c = env.clone();

    let dispatch = child.effect("dispatch")
        .on_ambiguous(Ambiguity::Recover)
        .needs(input)
        .identified_by(input)
        .perform(move |(input, env), identity| {
            let env = env.clone();
            let id = *identity;
            async move {
                if id % 2 == 0 {
                    env.record(format!("ack:{}", id));
                    let receipt = id + 900;
                    let r = env.open("receipt", receipt, &[]).await?;
                    Ok(env.hold_value(r))
                } else {
                    env.record(format!("unknown:{}", id));
                    tokio::time::sleep(Duration::from_millis(3)).await;
                    Err::<_, Error>("pending".into())
                }
            }
        })
        .recover_unknown(move |identity| {
            let env = env_c.clone();
            let id = *identity;
            async move {
                env.record(format!("reconcile:{}", id));
                Err::<(), Error>("StillUnknown".into())
            }
        })
        .compensate(move |_cx, receipt: Arc<crate::support::Resource>| {
            let env = env_c.clone();
            async move {
                env.record(format!("undo:{}", receipt.value));
                Ok(())
            }
        });

    let output = child.step("output")
        .needs(dispatch)
        .run(|_cx, _receipt| async move { Ok(1) });

    child.export(output).build(
        Policy::Isolate,
        Shutdown::within(Duration::from_secs(5)),
        Mode::Finite,
    ).expect("valid plan")
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report.into_result()
        .map_err(|r| r.to_string())
        .map(|opt| opt.ok_or_else(|| "missing completed output".to_string()))
        .and_then(|res| res.map(|val| *val))
}
