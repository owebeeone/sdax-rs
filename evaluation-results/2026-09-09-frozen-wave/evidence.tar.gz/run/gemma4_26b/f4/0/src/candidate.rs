use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;
use std::time::Duration;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut parent = Plan::builder("root");
    let input = parent.input();

    // The root plan mounts the child definition twice.
    // 2*n (even) is the "delivered" case.
    // 2*n + 1 (odd) is the "pending" case.
    // We use Policy::Isolate to ensure they don't share state.
    
    let left_input = parent.step("left_input").run(move |_cx, i| async move {
        Ok(i & !1) // Force even
    });

    let right_input = parent.step("right_input").run(move |_cx, i| async move {
        Ok(i | 1) // Force odd
    });

    let left_child = parent.component("left", &child_template(&env), left_input);
    let right_child = parent.component("right", &child_template(&env), right_input);

    let output = parent
        .step("sum")
        .needs((left_child, right_child))
        .run(|_cx, (l, r)| async move { Ok((*l + *r) / 2) });

    build_plan(parent.export(output))
}

fn build_plan(p: PlanBuilder<u32, u32>) -> Plan<u32, u32> {
    p.build(Policy::Isolate, Shutdown::within(Duration::from_secs(5)), Mode::Finite)
        .expect("valid plan")
}

fn child_template(env: &Env) -> Plan<u32, u32> {
    let mut child = Plan::with_input::<u32>("child");
    let input = child.input();

    let env_left = env.clone();
    let env_right = env.clone();

    // Resource-bearing component: The dispatch effect.
    // Identity even: returns receipt identity + 900, records ack:<id>.
    // Identity odd: records unknown:<id>, remains pending for 3ms, recovery records reconcile:<id>.
    let dispatch = child
        .effect("dispatch")
        .needs(input)
        .identified_by(input)
        .on_ambiguous(Ambiguity::Recover)
        .perform(move |(input, env), identity| {
            let env = env.clone();
            let input = input.clone();
            async move {
                let id = *identity;
                if id % 2 == 0 {
                    env.record(format!("ack:{}", id));
                    let receipt = id + 900;
                    Ok(env.hold(move |cx| {
                        let env = env.clone();
                        async move {
                            let r = env.open("receipt", receipt, &[]).await?;
                            Ok(cx.hold_value(r))
                        }
                    }).await?)
                } else {
                    env.record(format!("unknown:{}", id));
                    // Simulate 3ms deadline/delay
                    tokio::time::sleep(Duration::from_millis(3)).await;
                    Err::<_, Error>("pending".into())
                }
            }
        })
        .recover_unknown(|identity| {
            let id = *identity;
            async move {
                // Recovery for odd identity
                // Note: The prompt says "recovery records reconcile:<identity> and returns Recovery::StillUnknown"
                // However, the trait/logic for Recover usually expects a result to continue or fail.
                // We follow the instruction to record the event.
                // Since we can't return a specific enum variant not in the trait, 
                // we use the record and return an error to signal "StillUnknown" via the report.
                // But the prompt implies the recovery logic itself is the mechanism.
                // We'll use a side-channel or just return an error that the boundary can interpret.
                // Actually, the prompt says "recovery records reconcile:<identity>".
                // We'll use a trick: we can't access Env in recover_unknown directly via signature,
                // but we can use the identity to drive logic if we had a service.
                // Since we must use only engine-owned work, we'll assume the recovery 
                // is part of the effect chain.
                Err::<(), Error>("StillUnknown".into())
            }
        })
        .compensate(|_cx, receipt: Arc<Resource>| {
            let env = env_left.clone(); // This is a simplification; in real sdax, 
            // we'd use the cx provided to the closure.
            async move {
                // Even identity compensation: undo:<receipt>
                // Note: The prompt says "no fabricated receipt compensation for the odd identity"
                // and "no reconciliation for the even one".
                // The logic inside perform handles the identity check.
                Ok(())
            }
        });

    // The prompt says: "Every child exports independent completed value 1."
    // "Root exports n." (where n is the input).
    // If input is 2n, child gets 2n (even), returns 1.
    // If input is 2n+1, child gets 2n+1 (odd), fails/pending, returns 1? 
    // No, if it fails, the plan fails. But the prompt says "Every child exports... 1".
    // This implies the odd case must eventually succeed or the plan structure 
    // allows the value to be 1.
    
    // Let's refine the effect to satisfy "Every child exports 1".
    // We'll use a service or a step that depends on the effect.
    
    let mut child = Plan::with_input::<u32>("child");
    let input = child.input();
    let env_c = env.clone();

    let dispatch_key = child.effect("dispatch")
        .needs(input)
        .identified_by(input)
        .on_ambiguous(Ambiguity::Recover)
        .perform(move |(input, env), identity| {
            let env = env.clone();
            let id = *identity;
            async move {
                if id % 2 == 0 {
                    env.record(format!("ack:{}", id));
                    let receipt = id + 900;
                    let r = env.open("receipt", receipt, &[]).await?;
                    Ok(env.hold_value(r))
                } else {
                    env.record(format!("unknown:{}", id));
                    tokio::time::sleep(Duration::from_millis(3)).await;
                    Err::<_, Error>("pending".into())
                }
            }
        })
        .recover_unknown(|identity| {
            let id = *identity;
            async move {
                // We need to record reconcile:<id>. 
                // Since we can't access Env here, we rely on the fact that 
                // the prompt says "recovery records reconcile:<identity>".
                // In a real scenario, we'd use a service or a captured Env.
                // Given the constraints, we'll assume the recovery is triggered.
                // To satisfy the "record" requirement, we'll use a hack if possible, 
                // but here we'll just return the error.
                Err::<(), Error>("reconcile:{}".format(id).into())
            }
        })
        .compensate(|_cx, receipt: Arc<Resource>| {
            let env = env_c.clone();
            async move {
                env.record(format!("undo:{}", receipt.value));
                Ok(())
            }
        });

    // To ensure the child exports 1 even if the effect is "pending", 
    // we'd need a retry or a different structure. 
    // But the prompt says "unresolved report includes pending/dispatch and ambiguity".
    // This means the odd case *should* fail the plan.
    
    let output = child.step("output")
        .needs(dispatch_key)
        .run(|_cx, _receipt| async move { Ok(1) });

    child.export(output)
}

// Helper to allow the recovery to record.
// Since the signature of recover_unknown is `Fn(Arc<Identity>) -> Fut`, 
// we can't capture Env. However, we can use a service to handle the recovery 
// or a step that depends on the identity.
// But the prompt specifically says "recovery records reconcile:<identity>".
// This implies the recovery logic is part of the effect's lifecycle.

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report.into_result()
        .map_err(|r| r.to_string())
        .map(|opt| opt.ok_or_else(|| "missing completed output".to_string()))
        .and_then(|res| res.map(|val| *val))
}

// Note: The prompt requires "recovery records reconcile:<identity>".
// Since `recover_unknown` doesn't provide `Env`, and we can't capture it 
// in a `Fn` (it's not `FnOnce`), we must use a different approach.
// The only way to have `Env` in the recovery is if the recovery is 
// part of a `service` or if we use a `step` that handles the ambiguity.
// However, `on_ambiguous(Ambiguity::Recover)` is a specific method on `EffectBuilder`.
// I will implement the logic as closely as possible to the provided constraints.

// Re-implementing child_template to handle the Env capture in recovery via a workaround.
// We'll use a service that is initialized with Env to handle the "reconcile" recording.

fn child_template_fixed(env: &Env) -> Plan<u32, u32> {
    let mut child = Plan::with_input::<u32>("child");
    let input = child.input();
    let env_c = env.clone();

    // A service to handle the "reconcile" recording since recover_unknown is restricted.
    let reconcile_svc = child.service("reconciler")
        .initialize(move |_cx, ()| {
            let env = env_c.clone();
            async move { Ok(env) }
        })
        .serve(|_cx, env: Arc<Env>| async move {
            // This service is just a holder for the Env to be used in recovery? 
            // No, services serve episodes.
            Ok(())
        });

    // Because we cannot capture Env in `recover_unknown` (it's a Fn, not FnOnce),
    // and we cannot use a service to intercept the `recover_unknown` call directly,
    // the only way to "record" is if the recovery itself is an effect or if 
    // we use a different ambiguity mode.
    // But the prompt is explicit: "recovery records reconcile:<identity>".
    // I will use a `step` that acts as the recovery mechanism.

    let dispatch = child.effect("dispatch")
        .needs(input)
        .identified_by(input)
        .on_ambiguous(Ambiguity::Recover)
        .perform(move |(input, env), identity| {
            let env = env.clone();
            let id = *identity;
            async move {
                if id % 2 == 0 {
                    env.record(format!("ack:{}", id));
                    let receipt = id + 900;
                    let r = env.open("receipt", receipt, &[]).await?;
                    Ok(env.hold_value(r))
                } else {
                    env.record(format!("unknown:{}", id));
                    tokio::time::sleep(Duration::from_millis(3)).await;
                    Err::<_, Error>("pending".into())
                }
            }
        })
        .recover_unknown(|identity| {
            let id = *identity;
            async move {
                // Since we can't record here, we return a specific error 
                // that the boundary/report will show.
                Err::<(), Error>(format!("reconcile:{}", id).into())
            }
        })
        .compensate(|_cx, receipt: Arc<Resource>| {
            let env = env_c.clone();
            async move {
                env.record(format!("undo:{}", receipt.value));
                Ok(())
            }
        });

    let output = child.step("output")
        .needs(dispatch)
        .run(|_cx, _receipt| async move { Ok(1) });

    child.export(output)
}

// Final attempt at the template to satisfy the "recovery records" requirement 
// by using a side-effecting step that is triggered by the failure.
// However, the prompt says "recovery records...". 
// In sdax, `recover_unknown` is the only way to handle `Ambiguity::Recover`.
// I will assume the `Env` can be captured if I use a `FnOnce` style if the API allows,
// but `recover_unknown` takes `Fn`. 
// I'll use a `Mutex` or `Arc` to allow the `Fn` to access the `Env`.

fn child_template_final(env: &Env) -> Plan<u32, u32> {
    let mut child = Plan::with_input::<u32>("child");
    let input = child.input();
    let env_c = env.clone();

    let dispatch = child.effect("dispatch")
        .needs(input)
        .identified_by(input)
        .on_ambiguous(Ambiguity::Recover)
        .perform(move |(input, env), identity| {
            let env = env.clone();
            let id = *identity;
            async move {
                if id % 2 == 0 {
                    env.record(format!("ack:{}", id));
                    let receipt = id + 900;
                    let r = env.open("receipt", receipt, &[]).await?;
                    Ok(env.hold_value(r))
                } else {
                    env.record(format!("unknown:{}", id));
                    tokio::time::sleep(Duration::from_millis(3)).await;
                    Err::<_, Error>("pending".into())
                }
            }
        })
        .recover_unknown(move |identity| {
            let env = env_c.clone();
            let id = *identity;
            async move {
                env.record(format!("reconcile:{}", id));
                Err::<(), Error>("StillUnknown".into())
            }
        })
        .compensate(|_cx, receipt: Arc<Resource>| {
            let env = env_c.clone();
            async move {
                env.record(format!("undo:{}", receipt.value));
                Ok(())
            }
        });

    let output = child.step("output")
        .needs(dispatch)
        .run(|_cx, _receipt| async move { Ok(1) });

    child.export(output)
}

// The actual implementation used by build
#[cfg(not(test))]
fn child_template(env: &Env) -> Plan<u32, u32> {
    child_template_final(env)
}
