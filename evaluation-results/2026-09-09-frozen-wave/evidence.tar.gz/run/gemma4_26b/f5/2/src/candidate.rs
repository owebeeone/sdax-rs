use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;
use std::time::Duration;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut p = Plan::builder("root");
    let input: Key<u32> = p.input();

    // Cable resource: initialization retry logic
    let cable: Key<Resource> = p
        .resource("cable")
        .idempotent()
        .retry(Retry::attempts(2))
        .acquire(move |cx: Cx<Start>, input: Arc<u32>| {
            let env = env.clone();
            let attempt = cx.attempt();
            async move {
                env.record(format!("init:{}", attempt));
                if attempt == 1 {
                    Err("known error".into())
                } else {
                    let val = *input + 6;
                    let res = env.open("cable", val, &[]).await?;
                    // Use Cx<Acquire> via hold to satisfy type system
                    Ok(cx.hold_value(res))
                }
            }
        })
        .release(move |cx, cable: Arc<Resource>| {
            let env = env.clone();
            let cable = cable.clone();
            async move {
                env.close(&cable).await
            }
        });

    // Service relay: serving recovery and stop logic
    let service: Key<Resource> = p
        .service("relay")
        .idempotent()
        .restart(Restart::on_error(Backoff::fixed(Duration::from_millis(40))).max(2))
        .stop_within(Duration::from_millis(10))
        .initialize(move |_, _cable: Arc<Resource>| {
            async { Ok(()) }
        })
        .serve(move |cx, cable: Arc<Resource>| {
            let env = env.clone();
            let cable = cable.clone();
            async move {
                let episode = cx.episode();
                let handle_val = cable.value;
                let ptr = Arc::as_ptr(&cable);
                
                if episode <= 2 {
                    env.record(format!("serve:{}:{}:{:p}", episode, handle_val, ptr));
                    Err::<(), Error>("fail".into())
                } else {
                    if cx.is_stopping() {
                        env.record(format!("serve:{}:{}:{:p}:cooperatively-stopped", episode, handle_val, ptr));
                        Ok(())
                    } else {
                        cx.stop().await;
                        env.record(format!("serve:{}:{}:{:p}:cooperatively-stopped", episode, handle_val, ptr));
                        Ok(())
                    }
                }
            }
        });

    // Dependent observer: records once and exports handle
    let observer: Key<u32> = p
        .step("observer")
        .needs((input, cable, service))
        .run(move |cx, (input, cable, _service): (Arc<u32>, Arc<Resource>, Arc<Resource>)| {
            let env = env.clone();
            let cable = cable.clone();
            async move {
                let handle_val = cable.value;
                let ptr = Arc::as_ptr(&cable);
                env.record(format!("observer:{}:{}:{:p}", handle_val, ptr));
                Ok(handle_val)
            }
        });

    let output = p.export(observer);
    p.build(
        Policy::FailFast,
        Shutdown::within(Duration::from_secs(1)),
        Mode::Finite,
    ).expect("valid plan")
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report
        .into_result()
        .map_err(|r| r.to_string())?
        .as_deref()
        .copied()
        .ok_or_else(|| "missing output".to_string())
}
