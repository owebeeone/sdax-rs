use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;
use std::time::Duration;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut p = Plan::with_input::<u32>("candidate");
    let input: Key<u32> = p.input();

    let env_cable = env.clone();
    let env_cable_close = env.clone();
    let cable: Key<Resource> = p
        .resource("cable")
        .needs(input)
        .acquire(move |cx, n: Arc<u32>| {
            let env = env_cable.clone();
            async move {
                let res = env.open("cable", *n, &[]).await?;
                Ok(cx.hold_value(res))
            }
        })
        .release(move |_cx, cable: Arc<Resource>| {
            let env = env_cable_close.clone();
            async move {
                env.close(&cable).await
            }
        });

    let env_init = env.clone();
    let handle: Key<u32> = p
        .service("relay")
        .needs((input, cable))
        .idempotent()
        .retry(Retry::attempts(2).backoff(Backoff::fixed(Duration::from_millis(1))))
        .restart(Restart::on_error(Backoff::fixed(Duration::from_millis(40))).max(2))
        .stop_within(Duration::from_millis(10))
        .initialize(move |cx, (n, _cable): (Arc<u32>, Arc<Resource>)| {
            let env = env_init.clone();
            async move {
                let attempt = cx.attempt();
                env.record(format!("init:{attempt}"));
                if attempt == 1 {
                    Err::<u32, Error>("known init error".into())
                } else {
                    Ok(*n + 6)
                }
            }
        })
        .serve(move |cx, handle: Arc<u32>| {
            let env = env.clone();
            let episode = cx.episode();
            let handle_ptr = Arc::as_ptr(&handle) as usize;
            let handle_val = *handle;
            async move {
                env.record(format!("serve:{episode}:{handle_val}:{handle_ptr}"));
                if episode <= 2 {
                    Err::<(), Error>("serving failure".into())
                } else {
                    cx.stop().await;
                    env.record("cooperatively-stopped");
                    Ok(())
                }
            }
        });

    let env_obs = env.clone();
    let output: Key<u32> = p
        .step("observer")
        .needs((handle, cable))
        .run(move |_cx, (handle, _cable): (Arc<u32>, Arc<Resource>)| {
            let env = env_obs.clone();
            let handle_val = *handle;
            let handle_ptr = Arc::as_ptr(&handle) as usize;
            async move {
                env.record(format!("observer:{handle_val}:{handle_ptr}"));
                Ok(handle_val)
            }
        });

    p.export(output)
        .build(
            Policy::FailFast,
            Shutdown::within(Duration::from_millis(100)),
            Mode::Finite,
        )
        .expect("valid plan")
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report
        .into_result()
        .map_err(|r| r.to_string())?
        .as_deref()
        .copied()
        .ok_or_else(|| "missing completed output".to_owned())
}
