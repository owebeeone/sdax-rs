use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;
use std::time::Duration;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut child = Plan::with_input::<u32>("dispatch");
    let input: Key<u32> = child.input();

    let env_ack = env.clone();
    let env_undo = env.clone();
    let env_unknown = env.clone();
    let env_reconcile = env.clone();

    let dispatch: Key<u32> = child
        .effect("dispatch")
        .needs(input)
        .on_ambiguous(Ambiguity::Recover)
        .identified_by(input)
        .perform(move |cx, (input, identity): (Arc<u32>, Arc<u32>)| {
            let env_ack = env_ack.clone();
            let env_unknown = env_unknown.clone();
            async move {
                let id = *identity;
                if id % 2 == 0 {
                    env_ack.record(format!("ack:{id}"));
                    Ok(cx.hold_value(id + 900))
                } else {
                    env_unknown.record(format!("unknown:{id}"));
                    tokio::time::sleep(Duration::from_millis(3)).await;
                    Err::<u32, Error>("still unknown".into())
                }
            }
        })
        .recover_unknown(move |_cx, identity: Arc<u32>| {
            let env_reconcile = env_reconcile.clone();
            async move {
                let id = *identity;
                env_reconcile.record(format!("reconcile:{id}"));
                Ok(Recovery::StillUnknown)
            }
        })
        .compensate(move |_cx, receipt: Arc<u32>| {
            let env_undo = env_undo.clone();
            async move {
                env_undo.record(format!("undo:{receipt}"));
                Ok(())
            }
        });

    let output = child
        .step("completed value")
        .needs(dispatch)
        .run(|_cx, value: Arc<u32>| async move { Ok(1) });

    let mut parent = Plan::builder("root");
    let n_input: Key<u32> = parent.input();

    let mut outputs = Vec::new();
    let mut i = 0u32;
    while i < 10 {
        let child_input = parent
            .step(format!("input {i}"))
            .needs(n_input)
            .run(move |_cx, n: Arc<u32>| async move { Ok(2 * i + n % 2) });

        let bound = child.bind::<u32>("dispatch", dispatch).expect("bind");
        let out = parent.component(format!("mount {i}"), &bound, child_input);
        outputs.push(out);
        i += 1;
    }

    let root_output = parent
        .step("root export")
        .needs(n_input)
        .run(|_cx, n: Arc<u32>| async move { Ok(*n) });

    parent
        .build(
            Policy::Isolate,
            Shutdown::within(Duration::from_secs(1)),
            Mode::Finite,
        )
        .expect("valid plan")
        .export(root_output)
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report
        .into_result()
        .map_err(|r| r.to_string())?
        .as_deref()
        .copied()
        .ok_or_else(|| "missing completed output".to_owned())
}
