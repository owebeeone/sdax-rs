use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut root = Plan::builder("root");
    let input: Key<u32> = root.input();

    let trunk: Key<Resource> = root
        .resource("trunk")
        .needs(input)
        .acquire(move |cx, n: Arc<u32>| {
            let env = env.clone();
            async move {
                let r = env.open("trunk", *n, &[]).await?;
                Ok(cx.hold_value(r))
            }
        })
        .release(move |_cx, trunk: Arc<Resource>| {
            let env = env.clone();
            async move { env.close(trunk).await }
        });

    let mut middle = Plan::with_input::<u32>("middle");
    let m_input: Key<u32> = middle.input();
    let m_trunk: Key<Resource> = middle.port::<Resource>("trunk");

    let m_step: Key<u32> = middle
        .step("middle step")
        .needs((m_input, m_trunk))
        .run(|_cx, (n, _trunk): (Arc<u32>, Arc<Resource>)| async move { Ok(*n) });

    let middle_plan = middle
        .build(
            Policy::Isolate,
            Shutdown::within(std::time::Duration::from_secs(1)),
            Mode::Finite,
        )
        .expect("middle plan");

    let mut leaf = Plan::with_input::<u32>("leaf");
    let l_input: Key<u32> = leaf.input();
    let l_trunk: Key<Resource> = leaf.port::<Resource>("trunk");

    let red: Key<Resource> = leaf
        .resource("red")
        .needs((l_input, l_trunk))
        .acquire(move |cx, (n, trunk): (Arc<u32>, Arc<Resource>)| {
            let env = env.clone();
            async move {
                let r = env.open("red", *n + 1, std::slice::from_ref(trunk)).await?;
                Ok(cx.hold_value(r))
            }
        })
        .release(move |_cx, red: Arc<Resource>| {
            let env = env.clone();
            async move { env.close(red).await }
        });

    let blue: Key<Resource> = leaf
        .resource("blue")
        .needs((l_input, l_trunk))
        .acquire(move |cx, (n, trunk): (Arc<u32>, Arc<Resource>)| {
            let env = env.clone();
            async move {
                let r = env.open("blue", *n + 2, std::slice::from_ref(trunk)).await?;
                Ok(cx.hold_value(r))
            }
        })
        .release(move |_cx, blue: Arc<Resource>| {
            let env = env.clone();
            async move { env.close(blue).await }
        });

    let aggregate: Key<u32> = leaf
        .step("aggregate")
        .needs((red, blue))
        .run(|_cx, (_red, _blue): (Arc<Resource>, Arc<Resource>)| async move {
            Err::<u32, Error>(Box::new(Cause(
                "aggregation refused",
                Some(Box::new(Cause(
                    "checksum mismatch",
                    Some(Box::new(Cause("sector 19", None))),
                ))),
            )))
        });

    let leaf_plan = leaf
        .build(
            Policy::Isolate,
            Shutdown::within(std::time::Duration::from_secs(1)),
            Mode::Finite,
        )
        .expect("leaf plan");

    let m_bound = middle_plan.bind(m_trunk, trunk).expect("middle trunk binding");
    let l_bound = leaf_plan.bind(l_trunk, trunk).expect("leaf trunk binding");

    let middle_out = root.component("middle mount", &m_bound, input);
    let leaf_out = root.component("leaf mount", &l_bound, input);

    let output = root
        .step("root output")
        .needs((middle_out, leaf_out))
        .run(|_cx, (_m, _l): (Arc<u32>, Arc<u32>)| async move { Ok(0) });

    root.build(
        Policy::Isolate,
        Shutdown::within(std::time::Duration::from_secs(1)),
        Mode::Finite,
    )
    .expect("root plan")
    .export(output)
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report
        .into_result()
        .map_err(|r| r.to_string())
        .and_then(|v| v.as_deref().copied().ok_or_else(|| "missing output".to_owned()))
}
