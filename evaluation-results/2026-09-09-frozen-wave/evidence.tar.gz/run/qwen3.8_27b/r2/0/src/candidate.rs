use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;
use std::time::Duration;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut p = Plan::<u32, u32>::new();

    // Resource: cable (value = input n)
    let cable = p
        .resource("cable")
        .acquire(|cx, n: Arc<u32>| async move {
            let r = env.open("cable", *n, &[]).await?;
            Ok(cx.hold_value(r))
        })
        .release(|cx, r: Arc<Resource>| async move {
            env.close(r).await
        });

    // Service: relay (depends on cable)
    let relay = p
        .service("relay")
        .idempotent()
        .retry(Retry::attempts(2).backoff(Backoff::fixed(Duration::from_millis(1))))
        .restart(Restart::on_error(Backoff::fixed(Duration::from_millis(40))).max(2))
        .stop_within(Duration::from_millis(10))
        .shutdown_within(Duration::from_millis(100))
        .initialize(|cx, n: Arc<u32>| async move {
            let attempt = cx.attempt();
            env.record(format!("init:{}", attempt)).await;
            if attempt == 1 {
                Err::<u32, String>("known init error".into())
            } else {
                Ok(*n + 6)
            }
        })
        .serve(|cx, handle: Arc<u32>| async move {
            let episode = cx.episode();
            let ptr = Arc::as_ptr(handle) as usize;
            env.record(format!("serve:{}:{}:{}", episode, *handle, ptr)).await;
            if episode <= 2 {
                Err::<(), String>("serving failure".into())
            } else {
                cx.stop().await;
                env.record("cooperatively-stopped".to_string()).await;
                Ok(())
            }
        });

    // Observer step: depends on relay, records once, exports handle value
    let observer = p
        .step("observer")
        .needs((relay, cable))
        .perform(|cx, (relay_handle: Arc<u32>, _cable: Arc<Resource>)| async move {
            let ptr = Arc::as_ptr(relay_handle) as usize;
            env.record(format!("observer:{}:{}", *relay_handle, ptr)).await;
            Ok(*relay_handle)
        });

    p.export(observer);
    p
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report
        .into_result()
        .map_err(|e| format!("plan failed: {}", e))
}
