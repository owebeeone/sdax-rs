use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;
use std::time::Duration;

type Res = crate::support::Resource;

fn build_plan(env: Env) -> Plan<u32, u32> {
    // Leaf component: takes scalar input and sleeve resource port, opens lens
    let mut leaf = Plan::with_input::<u32>("leaf");
    let leaf_input: Key<u32> = leaf.input();
    let sleeve_port: Key<Res> = leaf.port::<Res>("sleeve");

    let leaf_env_acquire = env.clone();
    let leaf_env_release = env.clone();
    let lens: Key<Res> = leaf
        .resource("lens")
        .needs((leaf_input, sleeve_port))
        .acquire(move |cx, (scalar, sleeve): (Arc<u32>, Arc<Res>)| {
            let env = leaf_env_acquire.clone();
            async move {
                let value = sleeve.value * 2 + *scalar;
                let parents = [sleeve.as_ref()];
                let lens_res = env.open("lens", value, &parents).await?;
                Ok(cx.hold_value(lens_res))
            }
        })
        .release(move |_cx, lens: Arc<Res>| {
            let env = leaf_env_release.clone();
            async move {
                env.close(&lens).await
            }
        });

    let leaf_output = leaf
        .step("leaf output")
        .needs(lens)
        .run(|_cx, lens: Arc<Res>| async move { Ok(lens.value) });

    let leaf_plan = leaf
        .export(leaf_output)
        .build(
            Policy::FailFast,
            Shutdown::within(Duration::from_secs(1)),
            Mode::Finite,
        )
        .expect("valid leaf plan");

    // Middle component: takes tuple input and vault resource port, opens sleeve, mounts leaf
    let mut middle = Plan::with_input::<(u32, u32)>("middle");
    let middle_input: Key<(u32, u32)> = middle.input();
    let vault_port: Key<Res> = middle.port::<Res>("vault");

    let middle_env_acquire = env.clone();
    let middle_env_release = env.clone();
    let sleeve: Key<Res> = middle
        .resource("sleeve")
        .needs((middle_input, vault_port))
        .acquire(move |cx, (tuple, vault): (Arc<(u32, u32)>, Arc<Res>)| {
            let env = middle_env_acquire.clone();
            async move {
                let value = vault.value + tuple.0;
                let parents = [vault.as_ref()];
                let sleeve_res = env.open("sleeve", value, &parents).await?;
                Ok(cx.hold_value(sleeve_res))
            }
        })
        .release(move |_cx, sleeve: Arc<Res>| {
            let env = middle_env_release.clone();
            async move {
                env.close(&sleeve).await
            }
        });

    // Bind the leaf's sleeve port to the middle's sleeve resource
    let leaf_bound = leaf_plan.bind(sleeve_port, sleeve).expect("sleeve binding");

    // Mount the leaf component with the tuple.1 as scalar input
    let leaf_scalar = middle
        .step("leaf scalar")
        .needs(middle_input)
        .run(|_cx, tuple: Arc<(u32, u32)>| async move { Ok(tuple.1) });

    let middle_output = middle.component("leaf mount", &leaf_bound, leaf_scalar);

    let middle_plan = middle
        .export(middle_output)
        .build(
            Policy::FailFast,
            Shutdown::within(Duration::from_secs(1)),
            Mode::Finite,
        )
        .expect("valid middle plan");

    // Root: opens vault, creates tuple input, mounts middle
    let mut root = Plan::with_input::<u32>("root");
    let root_input: Key<u32> = root.input();

    let root_env_acquire = env.clone();
    let root_env_release = env.clone();
    let vault: Key<Res> = root
        .resource("vault")
        .needs(root_input)
        .acquire(move |cx, n: Arc<u32>| {
            let env = root_env_acquire.clone();
            async move {
                let value = 3 * *n;
                let parents: [&Res; 0] = [];
                let vault_res = env.open("vault", value, &parents).await?;
                Ok(cx.hold_value(vault_res))
            }
        })
        .release(move |_cx, vault: Arc<Res>| {
            let env = root_env_release.clone();
            async move {
                env.close(&vault).await
            }
        });

    // Create the tuple input (n+2, n+5)
    let tuple_input = root
        .step("tuple input")
        .needs(root_input)
        .run(|_cx, n: Arc<u32>| async move { Ok((*n + 2, *n + 5)) });

    // Bind the middle's vault port to the root's vault resource
    let middle_bound = middle_plan.bind(vault_port, vault).expect("vault binding");

    // Mount the middle component
    let root_output = root.component("middle mount", &middle_bound, tuple_input);

    root.export(root_output)
        .build(
            Policy::FailFast,
            Shutdown::within(Duration::from_secs(1)),
            Mode::Finite,
        )
        .expect("valid root plan")
}

pub fn build(env: Env) -> Plan<u32, u32> {
    build_plan(env)
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report
        .into_result()
        .map_err(|report| report.to_string())?
        .as_deref()
        .copied()
        .ok_or_else(|| "missing completed output".to_owned())
}
