use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut p = Plan::<u32, u32>::new();

    // Parent input: n
    let n = p.input("n");

    // Open west = n + 1
    let west = p
        .step("open-west")
        .needs(n)
        .perform(|cx, n: Arc<u32>| {
            let env = env.clone();
            async move {
                let value = *n + 1;
                let r = env.open("west", value, &[]).await?;
                Ok(cx.hold_value(r))
            }
        })
        .compensate(|_cx, r: Arc<support::Resource>| {
            let env = env.clone();
            async move {
                let _ = env.close(&r).await;
                Ok(())
            }
        });

    // Open east = n + 4
    let east = p
        .step("open-east")
        .needs(n)
        .perform(|cx, n: Arc<u32>| {
            let env = env.clone();
            async move {
                let value = *n + 4;
                let r = env.open("east", value, &[]).await?;
                Ok(cx.hold_value(r))
            }
        })
        .compensate(|_cx, r: Arc<support::Resource>| {
            let env = env.clone();
            async move {
                let _ = env.close(&r).await;
                Ok(())
            }
        });

    // Define the reusable child encoder
    let child = p.child("encoder");
    let port_tens = child.port::<support::Resource>("tens");
    let port_units = child.port::<support::Resource>("units");
    let bias = child.input::<u32>("bias");

    // Child body: open encoded resource with value 10*tens + units + bias
    child
        .step("encode")
        .needs((port_tens, port_units, bias))
        .perform(|cx, (tens, units, bias): (Arc<support::Resource>, Arc<support::Resource>, Arc<u32>)| {
            let env = env.clone();
            async move {
                let value = 10 * tens.value + units.value + *bias;
                let name = format!("slot-{}", *bias);
                let parents = [tens.as_ref(), units.as_ref()];
                let r = env.open(&name, value, &parents).await?;
                Ok(cx.hold_value(r))
            }
        })
        .compensate(|_cx, r: Arc<support::Resource>| {
            let env = env.clone();
            async move {
                let _ = env.close(&r).await;
                Ok(())
            }
        });

    // Mount low: tens=west, units=east, bias=2
    let low = p
        .mount("low", &child)
        .bind(port_tens, west)
        .bind(port_units, east)
        .input(bias, 2u32)
        .export();

    // Mount high: tens=east, units=west, bias=5
    let high = p
        .mount("high", &child)
        .bind(port_tens, east)
        .bind(port_units, west)
        .input(bias, 5u32)
        .export();

    // Final: low * 1000 + high
    let result = p
        .step("combine")
        .needs((low, high))
        .perform(|_cx, (low, high): (Arc<support::Resource>, Arc<support::Resource>)| async move {
            Ok(low.value * 1000 + high.value)
        });

    p.export(result);
    p
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    match report.into_result() {
        Ok(v) => Ok(*v),
        Err(e) => Err(format!("report error: {}", e)),
    }
}
