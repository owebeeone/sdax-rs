use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;
use std::time::Duration;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut child = Plan::with_input::<u32>("encoder");
    let bias: Key<u32> = child.input();
    let tens_port: Key<Resource> = child.port::<Resource>("tens");
    let units_port: Key<Resource> = child.port::<Resource>("units");

    let env_open = env.clone();
    let env_close = env.clone();
    let encoded: Key<Resource> = child
        .resource("encoded")
        .needs((bias, tens_port, units_port))
        .acquire(
            move |cx, (bias, tens, units): (Arc<u32>, Arc<Resource>, Arc<Resource>)| {
                let env = env_open.clone();
                async move {
                    let value = 10 * tens.value + units.value + *bias;
                    let name = format!("slot-{bias}");
                    let parents: Vec<&Resource> = vec![&tens, &units];
                    let res = env.open(&name, value, &parents).await?;
                    Ok(cx.hold(res))
                }
            },
        )
        .release(move |_cx, encoded: Arc<Resource>| {
            let env = env_close.clone();
            async move { env.close(&encoded).await }
        });

    let output = child
        .step("value")
        .needs(encoded)
        .run(|_cx, res: Arc<Resource>| async move { Ok(res.value) });

    let child_plan = child
        .export(output)
        .build(
            Policy::FailFast,
            Shutdown::within(Duration::from_secs(1)),
            Mode::Finite,
        )
        .expect("valid child plan");

    let mut parent = Plan::builder("mirrored encoders");
    let input: Key<u32> = parent.input();

    let env_west = env.clone();
    let env_west_close = env.clone();
    let west: Key<Resource> = parent
        .resource("west")
        .needs(input)
        .acquire(move |cx, n: Arc<u32>| {
            let env = env_west.clone();
            async move {
                let res = env.open("west", n + 1, &[]).await?;
                Ok(cx.hold(res))
            }
        })
        .release(move |_cx, west: Arc<Resource>| {
            let env = env_west_close.clone();
            async move { env.close(&west).await }
        });

    let env_east = env.clone();
    let env_east_close = env.clone();
    let east: Key<Resource> = parent
        .resource("east")
        .needs(input)
        .acquire(move |cx, n: Arc<u32>| {
            let env = env_east.clone();
            async move {
                let res = env.open("east", n + 4, &[]).await?;
                Ok(cx.hold(res))
            }
        })
        .release(move |_cx, east: Arc<Resource>| {
            let env = env_east_close.clone();
            async move { env.close(&east).await }
        });

    let low_bound = child_plan
        .bind(tens_port, west)
        .and_then(|p| p.bind(units_port, east))
        .expect("low bindings");

    let high_bound = child_plan
        .bind(tens_port, east)
        .and_then(|p| p.bind(units_port, west))
        .expect("high bindings");

    let low_bias = parent
        .step("low bias")
        .run(|_cx, ()| async move { Ok(2u32) });
    let high_bias = parent
        .step("high bias")
        .run(|_cx, ()| async move { Ok(5u32) });

    let low_out = parent.component("low", &low_bound, low_bias);
    let high_out = parent.component("high", &high_bound, high_bias);

    let final_out = parent
        .step("combine")
        .needs((low_out, high_out))
        .run(|_cx, (low, high): (Arc<u32>, Arc<u32>)| async move {
            Ok(low * 1000 + high)
        });

    parent
        .export(final_out)
        .build(
            Policy::FailFast,
            Shutdown::within(Duration::from_secs(1)),
            Mode::Finite,
        )
        .expect("valid parent plan")
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report
        .into_result()
        .map_err(|r| r.to_string())?
        .as_deref()
        .copied()
        .ok_or_else(|| "missing completed output".to_owned())
}
