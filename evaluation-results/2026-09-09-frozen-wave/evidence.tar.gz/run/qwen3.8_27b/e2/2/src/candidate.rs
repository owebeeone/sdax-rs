use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;
use std::time::Duration;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut parent = Plan::builder("parent");
    let input: Key<u32> = parent.input();

    let env_base = env.clone();
    let base: Key<Resource> = parent
        .resource("base")
        .needs(input)
        .acquire(move |cx, n: Arc<u32>| {
            let env = env_base.clone();
            async move {
                env.record(format!("attempt:base:{}", cx.attempt()));
                let r = env.open("base", *n, &[]).await?;
                Ok(cx.hold_value(r))
            }
        })
        .release(move |_cx, base: Arc<Resource>| {
            let env = env_base.clone();
            async move {
                env.close(&base).await
            }
        });

    let mut child = Plan::with_input::<u32>("child");
    let child_input: Key<u32> = child.input();
    let base_port: Key<Resource> = child.port::<Resource>("base");

    let env_rates = env.clone();
    let rates: Key<Resource> = child
        .resource("rates")
        .needs((child_input, base_port))
        .idempotent()
        .retry(Retry::attempts(2).backoff(Backoff::fixed(Duration::from_millis(1))))
        .acquire(move |cx, (offset, base): (Arc<u32>, Arc<Resource>)| {
            let env = env_rates.clone();
            async move {
                env.record(format!("attempt:rates:{}", cx.attempt()));
                if cx.attempt() == 1 {
                    return Err("transient rates".into());
                }
                let r = env
                    .open("rates", *offset, std::slice::from_ref(&base.as_ref()))
                    .await?;
                Ok(cx.hold_value(r))
            }
        })
        .release(move |_cx, rates: Arc<Resource>| {
            let env = env_rates.clone();
            async move {
                env.close(&rates).await
            }
        });

    let env_derived = env.clone();
    let derived: Key<Resource> = child
        .resource("derived")
        .needs((base_port, rates))
        .acquire(move |cx, (base, rates): (Arc<Resource>, Arc<Resource>)| {
            let env = env_derived.clone();
            async move {
                env.record(format!("attempt:derived:{}", cx.attempt()));
                let value = base.value + rates.value;
                let parents = [base.as_ref(), rates.as_ref()];
                let r = env.open("derived", value, &parents).await?;
                Ok(cx.hold_value(r))
            }
        })
        .release(move |_cx, derived: Arc<Resource>| {
            let env = env_derived.clone();
            async move {
                env.close(&derived).await
            }
        });

    let output: Key<u32> = child
        .step("output")
        .needs(derived)
        .run(|_cx, d: Arc<Resource>| async move { Ok(d.value) });

    let child_plan = child
        .export(output)
        .build(
            Policy::FailFast,
            Shutdown::within(Duration::from_secs(1)),
            Mode::Finite,
        )
        .expect("valid child plan");

    let bound = parent.bind(&child_plan, base_port, base).expect("bind base");
    let child_mount = parent.component("child", &bound, child_input);

    let final_output: Key<u32> = parent
        .step("final")
        .needs(child_mount)
        .run(|_cx, v: Arc<u32>| async move { Ok(*v) });

    parent
        .export(final_output)
        .build(
            Policy::FailFast,
            Shutdown::within(Duration::from_secs(1)),
            Mode::Finite,
        )
        .expect("valid parent plan")
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report
        .into_result()
        .map_err(|r| r.to_string())?
        .as_deref()
        .copied()
        .ok_or_else(|| "missing completed output".to_owned())
}
