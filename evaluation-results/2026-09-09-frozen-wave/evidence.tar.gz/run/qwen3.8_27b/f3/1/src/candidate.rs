use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;
use std::time::Duration;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut p = Plan::with_input::<u32>("candidate");
    let input: Key<u32> = p.input();

    // Root input n opens permit value n.
    let permit: Key<Resource> = p
        .resource("permit")
        .needs(input)
        .acquire(move |cx, n: Arc<u32>| {
            let env = env.clone();
            async move {
                let r = env.open("permit", *n, &[]).await?;
                Ok(cx.hold_value(r))
            }
        })
        .release(move |_cx, permit: Arc<Resource>| {
            let env = env.clone();
            async move {
                env.close(&permit).await
            }
        });

    // Build a per-run identity u32 n*100+17 as a step value, declared before effect send.
    let identity: Key<u32> = p
        .step("identity")
        .needs((input, permit))
        .run(move |_cx, (n, _permit): (Arc<u32>, Arc<Resource>)| async move {
            Ok(*n * 100 + 17)
        });

    // send has exactly three total idempotent attempts, fixed 1ms backoff, 4ms body deadline,
    // and unknown-outcome recovery.
    let send: Key<u32> = p
        .effect("send")
        .needs((identity, permit))
        .idempotent()
        .retry(Retry::attempts(3).backoff(Backoff::fixed(Duration::from_millis(1))))
        .on_ambiguous(Ambiguity::Recover)
        .identified_by(identity)
        .perform(move |cx, ((identity, permit), id): ((Arc<u32>, Arc<Resource>), Arc<u32>)| {
            let env = env.clone();
            async move {
                let attempt = cx.attempt();
                let identity_val = *identity;
                let permit_val = permit.value;
                let id_ptr = Arc::as_ptr(&id) as usize;
                env.record(format!("send:{}:{}:{}:{}", attempt, identity_val, permit_val, id_ptr));

                if attempt <= 2 {
                    Err::<u32, Error>(format!("send attempt {} failed", attempt).into())
                } else {
                    // Attempt 3 remains pending without receipt - simulate by returning error
                    // that triggers recovery
                    Err::<u32, Error>("send attempt 3 pending".into())
                }
            }
        })
        .recover_unknown(move |_cx, id: Arc<u32>| {
            let env = env.clone();
            async move {
                let identity_val = *id;
                let attempt = 3; // recovery runs after all attempts
                env.record(format!("recover:{}:{}", attempt, identity_val));

                // Check that permit is still live
                if env.live_count() != 1 {
                    return Err::<(), Error>("permit not live at recovery".into());
                }
                env.record("permit-live-at-recovery");

                // Open audit as a child of permit, then close it before permit release
                let audit = env.open("audit", identity_val, &[]).await?;
                env.close(&audit).await?;

                Ok(())
            }
        })
        .compensate(move |_cx, _receipt: Arc<u32>| async move {
            // Compensation must not run
            Ok(())
        });

    // Export an independent completed n+1 data step.
    let output: Key<u32> = p
        .step("output")
        .needs((input, send))
        .run(move |_cx, (n, _send): (Arc<u32>, Arc<u32>)| async move {
            Ok(*n + 1)
        });

    p.build(
        Policy::FailFast,
        Shutdown::within(Duration::from_secs(1)),
        Mode::Finite,
    )
    .expect("valid plan")
    .export(output)
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report
        .into_result()
        .map_err(|report| report.to_string())?
        .as_deref()
        .copied()
        .ok_or_else(|| "missing completed output".to_owned())
}
