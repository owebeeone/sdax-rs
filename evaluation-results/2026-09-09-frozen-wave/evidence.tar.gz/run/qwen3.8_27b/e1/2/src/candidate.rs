use crate::support::*;
use sdax::prelude::*;
use std::sync::Arc;
use std::time::Duration;

pub fn build(env: Env) -> Plan<u32, u32> {
    let mut p = Plan::with_input::<u32>("pipeline");
    let input: Key<u32> = p.input();

    let env_base = env.clone();
    let env_base_release = env_base.clone();
    let base: Key<Resource> = p
        .resource("base")
        .needs(input)
        .acquire(move |cx, n: Arc<u32>| {
            let env = env_base.clone();
            async move {
                let res = env.open("base", *n, &[]).await?;
                Ok(cx.hold_value(res))
            }
        })
        .release(move |_cx, base: Arc<Resource>| {
            let env = env_base_release.clone();
            async move {
                env.close(&base).await
            }
        });

    let env_derived = env.clone();
    let env_derived_release = env_derived.clone();
    let derived: Key<Resource> = p
        .resource("derived")
        .needs((input, base))
        .acquire(move |cx, (_n, base): (Arc<u32>, Arc<Resource>)| {
            let env = env_derived.clone();
            async move {
                let parents = [base.as_ref()];
                let res = env.open("derived", base.value + 5, &parents).await?;
                Ok(cx.hold_value(res))
            }
        })
        .release(move |_cx, derived: Arc<Resource>| {
            let env = env_derived_release.clone();
            async move {
                env.close(&derived).await
            }
        });

    let completed: Key<u32> = p
        .step("completed")
        .needs(derived)
        .run(|_cx, derived: Arc<Resource>| async move {
            Ok(derived.value * 2)
        });

    p.export(completed)
        .build(
            Policy::FailFast,
            Shutdown::within(Duration::from_secs(1)),
            Mode::Finite,
        )
        .expect("valid plan")
}

pub fn boundary(report: Report<u32>) -> Result<u32, String> {
    report
        .into_result()
        .map_err(|r| r.to_string())?
        .as_deref()
        .copied()
        .ok_or_else(|| "missing completed output".to_owned())
}
